package com.alliumvault.neuronalesnetz;


import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.alliumvault.neuronalesnetz.adapters.NetListAdapter;
import com.alliumvault.neuronalesnetz.databases.NetListDatabaseHandler;
import com.alliumvault.neuronalesnetz.models.NetListModel;
import com.alliumvault.neuronalesnetz.starters.FileManager;
import com.alliumvault.neuronalesnetz.starters.UniversalStarter;
import com.alliumvault.neuronalesnetz.views.PaintView;
import com.google.android.material.navigation.NavigationView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MyNetActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    static boolean isLearning = false;
    DrawerLayout drawer;
    NavigationView navigationView;
    PaintView paintView, paintViewTest;
    LinearLayout layoutNetList, layoutTestView, layoutNewNet, layoutCreateLearningData, layoutLearnAndSave;
    Button btnCreateNewNet, btnCheck, btnClearTest, btnNext1, btnNext2, btnAddData, btnClear, btnStartStopLearning, btnFinishLearning;
    RecyclerView recyclerViewNetList;
    TextView firstGuessTxt, learningPercentageTxt;
    ScrollView scrollViewStructure;
    EditText editTextInputNeurons, editTextHiddenNeurons, editTextOutputNeurons, editTextWantedOutputNeuron, editTextNetworkName;
    String networkName;
    int numImageRes, numHiddenNeurons, numOutputNeurons;
    int numLearningData = 0;

    private void initBtns() {
        btnCreateNewNet.setOnClickListener(v -> {
            layoutNetList.setVisibility(View.GONE);
            layoutNewNet.setVisibility(View.VISIBLE);
            scrollViewStructure.setVisibility(View.VISIBLE);
        });

        btnNext1.setOnClickListener(v -> checkCreatedStructure());

        btnNext2.setOnClickListener(v -> checkLearningData());

        btnAddData.setOnClickListener(v -> addToLearningData());

        btnStartStopLearning.setOnClickListener(v -> manageLearning());

        btnFinishLearning.setOnClickListener(v -> finishLearning());

        btnClear.setOnClickListener(v -> paintView.clear());
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_net);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.error, R.string.error);
        //noinspection deprecation
        drawer.setDrawerListener(toggle);
        toggle.syncState();
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        init();
        initBtns();
    }

    private void manageLearning() {
        if (isLearning) {
            isLearning = false;
            btnStartStopLearning.setText(R.string.start_learning);
            stopLearning();
        } else {
            isLearning = true;
            btnStartStopLearning.setText(R.string.stop_learning);
            Thread t = new Thread(this::startLearning);
            t.start();
        }
    }

    private void stopLearning() {
        try {
            btnFinishLearning.setVisibility(View.VISIBLE);
            FileManager.setLearningStatus(networkName, isLearning);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void startLearning() {
        try {
            btnFinishLearning.setVisibility(View.GONE);
            FileManager.setLearningStatus(networkName, isLearning);
            UniversalStarter.startLearning(learningPercentageTxt, numImageRes, numHiddenNeurons, numOutputNeurons, networkName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void finishLearning() {
        NetListDatabaseHandler netListDatabaseHandler = new NetListDatabaseHandler(MyNetActivity.this);
        netListDatabaseHandler.addList(networkName, String.valueOf(System.currentTimeMillis()));

        SharedPreferences newLocationSharedPreferences = getSharedPreferences(networkName, Context.MODE_PRIVATE);
        newLocationSharedPreferences.edit().putInt("input", numImageRes).apply();
        newLocationSharedPreferences.edit().putInt("hidden", numHiddenNeurons).apply();
        newLocationSharedPreferences.edit().putInt("out", numOutputNeurons).apply();

        Log.d("GGGGGGG", "input" + numImageRes);
        Log.d("GGGGGGG", "hidden" + numHiddenNeurons);
        Log.d("GGGGGGG", "out" + numOutputNeurons);
        Log.d("GGGGGGG", "networkName" + networkName);

        final Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(() -> {
            //Do something after 100ms

            Intent mStartActivity = new Intent(MyNetActivity.this, MyNetActivity.class);
            int mPendingIntentId = 123456;
            PendingIntent mPendingIntent = PendingIntent.getActivity(MyNetActivity.this, mPendingIntentId, mStartActivity, PendingIntent.FLAG_CANCEL_CURRENT);
            AlarmManager mgr = (AlarmManager) MyNetActivity.this.getSystemService(Context.ALARM_SERVICE);
            mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 10, mPendingIntent);
            System.exit(0);
        }, 1000);
    }

    private void addToLearningData() {
        if (!editTextWantedOutputNeuron.getText().toString().trim().equals("")) {
            FileManager.addDigit(paintView.getBitmap(), Integer.parseInt(editTextWantedOutputNeuron.getText().toString().trim()), numImageRes, networkName);
            paintView.clear();
            editTextWantedOutputNeuron.getText().clear();
            numLearningData++;
        } else {
            editTextWantedOutputNeuron.setError(getString(R.string.please_fill_in_everything));
        }
    }

    private void checkLearningData() {
        if (numLearningData < numOutputNeurons) {
            Toast.makeText(MyNetActivity.this, getString(R.string.please_create_more_learning_data), Toast.LENGTH_SHORT).show();
        } else {
            layoutCreateLearningData.setVisibility(View.GONE);
            layoutLearnAndSave.setVisibility(View.VISIBLE);
        }
    }

    private void checkCreatedStructure() {
        if (editTextInputNeurons.getText().toString().trim().equals("") ||
                editTextHiddenNeurons.getText().toString().trim().equals("") ||
                editTextOutputNeurons.getText().toString().trim().equals("") ||
                editTextNetworkName.getText().toString().trim().equals("")) {
            Toast.makeText(MyNetActivity.this, getString(R.string.please_fill_in_everything), Toast.LENGTH_SHORT).show();
        } else if (Integer.parseInt(editTextInputNeurons.getText().toString().trim()) < 10) {
            editTextInputNeurons.setError(getString(R.string.to_low_res));
        } else if (Integer.parseInt(editTextInputNeurons.getText().toString().trim()) > 1000000) {
            editTextInputNeurons.setError(getString(R.string.to_high_res));
        } else if (Integer.parseInt(editTextHiddenNeurons.getText().toString().trim()) < Integer.parseInt(editTextOutputNeurons.getText().toString().trim())) {
            editTextHiddenNeurons.setError(getString(R.string.not_enough_neurons));
        } else if (Integer.parseInt(editTextHiddenNeurons.getText().toString().trim()) > 1000000) {
            editTextHiddenNeurons.setError(getString(R.string.to_many_neurons));
        } else if (Integer.parseInt(editTextOutputNeurons.getText().toString().trim()) > 1000000) {
            editTextOutputNeurons.setError(getString(R.string.to_many_neurons));
        } else if (Integer.parseInt(editTextOutputNeurons.getText().toString().trim()) < 2) {
            editTextOutputNeurons.setError(getString(R.string.not_enough_neurons));
        } else {
            networkName = editTextNetworkName.getText().toString().trim();

            numImageRes = Integer.parseInt(editTextInputNeurons.getText().toString().trim());
            numHiddenNeurons = Integer.parseInt(editTextHiddenNeurons.getText().toString().trim());
            numOutputNeurons = Integer.parseInt(editTextOutputNeurons.getText().toString().trim());

            scrollViewStructure.setVisibility(View.GONE);
            layoutCreateLearningData.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            onNavigationItemSelected(navigationView.getMenu().getItem(0));
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        //here is the main place where we need to work on.
        int id = item.getItemId();
        switch (id) {

            case R.id.nav_home:
                Intent mStartActivity = new Intent(MyNetActivity.this, MainActivity.class);
                int mPendingIntentId = 123456;
                PendingIntent mPendingIntent = PendingIntent.getActivity(MyNetActivity.this, mPendingIntentId, mStartActivity, PendingIntent.FLAG_CANCEL_CURRENT);
                AlarmManager mgr = (AlarmManager) MyNetActivity.this.getSystemService(Context.ALARM_SERVICE);
                mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 10, mPendingIntent);
                System.exit(0);
                break;

            case R.id.introduction:
                Intent mStartActivity1 = new Intent(MyNetActivity.this, IntroductionActivity.class);
                int mPendingIntentId1 = 123456;
                PendingIntent mPendingIntent1 = PendingIntent.getActivity(MyNetActivity.this, mPendingIntentId1, mStartActivity1, PendingIntent.FLAG_CANCEL_CURRENT);
                AlarmManager mgr1 = (AlarmManager) MyNetActivity.this.getSystemService(Context.ALARM_SERVICE);
                mgr1.set(AlarmManager.RTC, System.currentTimeMillis() + 10, mPendingIntent1);
                System.exit(0);
                break;

            case R.id.my_net:
                drawer.closeDrawer(GravityCompat.START);
                break;

            case R.id.calculator:
                Intent mStartActivity2 = new Intent(MyNetActivity.this, CalculatorActivity.class);
                int mPendingIntentId2 = 123456;
                PendingIntent mPendingIntent2 = PendingIntent.getActivity(MyNetActivity.this, mPendingIntentId2, mStartActivity2, PendingIntent.FLAG_CANCEL_CURRENT);
                AlarmManager mgr2 = (AlarmManager) MyNetActivity.this.getSystemService(Context.ALARM_SERVICE);
                mgr2.set(AlarmManager.RTC, System.currentTimeMillis() + 10, mPendingIntent2);
                System.exit(0);
                break;

            case R.id.nav_more:
                Intent mStartActivity3 = new Intent(MyNetActivity.this, MoreActivity.class);
                int mPendingIntentId3 = 123456;
                PendingIntent mPendingIntent3 = PendingIntent.getActivity(MyNetActivity.this, mPendingIntentId3, mStartActivity3, PendingIntent.FLAG_CANCEL_CURRENT);
                AlarmManager mgr3 = (AlarmManager) MyNetActivity.this.getSystemService(Context.ALARM_SERVICE);
                mgr3.set(AlarmManager.RTC, System.currentTimeMillis() + 10, mPendingIntent3);
                System.exit(0);
                break;

            case R.id.nav_settings:
                Intent mStartActivity4 = new Intent(MyNetActivity.this, SettingsActivity.class);
                int mPendingIntentId4 = 123456;
                PendingIntent mPendingIntent4 = PendingIntent.getActivity(MyNetActivity.this, mPendingIntentId4, mStartActivity4, PendingIntent.FLAG_CANCEL_CURRENT);
                AlarmManager mgr4 = (AlarmManager) MyNetActivity.this.getSystemService(Context.ALARM_SERVICE);
                mgr4.set(AlarmManager.RTC, System.currentTimeMillis() + 10, mPendingIntent4);
                System.exit(0);
                break;
        }

        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void init() {
        paintView = findViewById(R.id.paintView);
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        paintView.init(metrics);

        paintViewTest = findViewById(R.id.paintView_test);
        DisplayMetrics metricsTest = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metricsTest);
        paintViewTest.init(metricsTest);

        editTextInputNeurons = findViewById(R.id.et_input);
        editTextHiddenNeurons = findViewById(R.id.et_hidden);
        editTextOutputNeurons = findViewById(R.id.et_output);
        editTextWantedOutputNeuron = findViewById(R.id.responding_output_neuron);
        editTextNetworkName = findViewById(R.id.et_net_name);

        firstGuessTxt = findViewById(R.id.first_test_guess_and_percentage);
        learningPercentageTxt = findViewById(R.id.txt_learning_percentage);

        scrollViewStructure = findViewById(R.id.scroll_view_structure);

        layoutNetList = findViewById(R.id.layout_my_net_list);
        layoutTestView = findViewById(R.id.view_test);
        layoutNewNet = findViewById(R.id.layout_new_net);
        layoutCreateLearningData = findViewById(R.id.view_test_data);
        layoutLearnAndSave = findViewById(R.id.view_learn_and_save);

        btnCreateNewNet = findViewById(R.id.btn_create_new_net);
        btnCheck = findViewById(R.id.check);
        btnClearTest = findViewById(R.id.btn_clear_test);
        btnNext1 = findViewById(R.id.btn_next1);
        btnNext2 = findViewById(R.id.btn_next2);
        btnAddData = findViewById(R.id.btn_add_to_test_data);
        btnClear = findViewById(R.id.btn_clear);
        btnStartStopLearning = findViewById(R.id.btn_start_stop_learning);
        btnFinishLearning = findViewById(R.id.btn_finish_learning);

        recyclerViewNetList = findViewById(R.id.recycler_view_my_net_list);
        recyclerViewNetList.setAdapter(new NetListAdapter(getTitles(), MyNetActivity.this));
        recyclerViewNetList.setLayoutManager(new LinearLayoutManager(this));

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_DENIED) {
            ActivityCompat
                    .requestPermissions(
                            this,
                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                            0);
        } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0);
        }
    }

    private ArrayList<String> getTitles() {
        ArrayList<String> ccTes = new ArrayList<>();
        NetListDatabaseHandler netListDatabaseHandler = new NetListDatabaseHandler(MyNetActivity.this);
        List<NetListModel> lists = netListDatabaseHandler.getAllLists();

        for (NetListModel netListModel : lists) {
            ccTes.add(netListModel.getTitle());
        }
        return ccTes;
    }

}