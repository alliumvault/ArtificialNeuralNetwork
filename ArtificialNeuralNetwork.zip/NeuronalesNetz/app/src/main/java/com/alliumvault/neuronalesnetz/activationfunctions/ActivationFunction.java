package com.alliumvault.neuronalesnetz.activationfunctions;

public interface ActivationFunction {
    public static Boolean ActivationBoolean = new Boolean();
    public static Identity ActivationIdentity = new Identity();
    public static Sigmoid ActivationSigmoid = new Sigmoid();
    public static HyperbolicTangent ActivationHyperbolicTangent = new HyperbolicTangent();
    public static ReLu ActivationReLu = new ReLu();

    public float activation(float input);

    public float derivative(float input);
}
