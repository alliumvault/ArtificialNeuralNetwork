package com.alliumvault.neuronalesnetz;


import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.alliumvault.neuronalesnetz.starters.FileManager;
import com.alliumvault.neuronalesnetz.starters.UniversalStarter;
import com.alliumvault.neuronalesnetz.views.PaintView;
import com.google.android.material.navigation.NavigationView;

public class CustomTestActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout drawer;
    NavigationView navigationView;

    TextView titleText, inTxt, hiddenTxt, outTxt, firstGuessTxt;
    Button btnCheck, btnClear;
    PaintView paintView;

    String netName;

    int numIn, numHidden, numOut;
    int delay = 1000;

    Handler handler = new Handler();
    Runnable runnable;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_test);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.error, R.string.error);
        //noinspection deprecation
        drawer.setDrawerListener(toggle);
        toggle.syncState();
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        titleText = findViewById(R.id.title_txt);
        inTxt = findViewById(R.id.num_in);
        hiddenTxt = findViewById(R.id.num_hidden);
        outTxt = findViewById(R.id.num_out);
        firstGuessTxt = findViewById(R.id.first_test_guess_and_percentage);
        btnCheck = findViewById(R.id.check);
        btnClear = findViewById(R.id.btn_clear_test);

        paintView = findViewById(R.id.paintView_test);
        DisplayMetrics metricsTest = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metricsTest);
        paintView.init(metricsTest);

        SharedPreferences newLocationSharedPreferences = getSharedPreferences("net_list", Context.MODE_PRIVATE);

        SharedPreferences newItemSharedPreferences = getSharedPreferences(newLocationSharedPreferences.getString("selectedItem", "error"), Context.MODE_PRIVATE);

        netName = newLocationSharedPreferences.getString("selectedItem", "error");
        titleText.setText(netName);
        numIn = newItemSharedPreferences.getInt("input", 0);
        numHidden = newItemSharedPreferences.getInt("hidden", 0);
        numOut = newItemSharedPreferences.getInt("out", 0);
        initNet();

        btnClear.setOnClickListener(v -> paintView.clear());
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void initNet() {
        UniversalStarter.load(hiddenTxt, CustomTestActivity.this, numIn, numOut, numHidden, netName);

        handler.postDelayed(runnable = () -> {
            handler.postDelayed(runnable, delay);
            firstGuessTxt.setText(String.valueOf(UniversalStarter.test(FileManager.getCustomDigit(paintView.getBitmap(), 0, numIn), CustomTestActivity.this,
                    hiddenTxt, hiddenTxt, hiddenTxt, numIn, numOut)));
        }, delay);
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            handler.removeCallbacks(runnable);
            Intent mStartActivity3 = new Intent(CustomTestActivity.this, MyNetActivity.class);
            int mPendingIntentId3 = 123456;
            PendingIntent mPendingIntent3 = PendingIntent.getActivity(CustomTestActivity.this, mPendingIntentId3, mStartActivity3, PendingIntent.FLAG_CANCEL_CURRENT);
            AlarmManager mgr3 = (AlarmManager) CustomTestActivity.this.getSystemService(Context.ALARM_SERVICE);
            mgr3.set(AlarmManager.RTC, System.currentTimeMillis() + 10, mPendingIntent3);
            System.exit(0);
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        //here is the main place where we need to work on.
        int id = item.getItemId();
        switch (id) {

            case R.id.nav_home:
                Intent pIntent = new Intent(this, MainActivity.class);
                startActivity(pIntent);
                break;

            case R.id.introduction:
                Intent aIntent = new Intent(this, IntroductionActivity.class);
                startActivity(aIntent);
                break;

            case R.id.my_net:
                Intent mStartActivity3 = new Intent(CustomTestActivity.this, MyNetActivity.class);
                int mPendingIntentId3 = 123456;
                PendingIntent mPendingIntent3 = PendingIntent.getActivity(CustomTestActivity.this, mPendingIntentId3, mStartActivity3, PendingIntent.FLAG_CANCEL_CURRENT);
                AlarmManager mgr3 = (AlarmManager) CustomTestActivity.this.getSystemService(Context.ALARM_SERVICE);
                mgr3.set(AlarmManager.RTC, System.currentTimeMillis() + 10, mPendingIntent3);
                System.exit(0);
                break;

            case R.id.calculator:
                Intent cIntent = new Intent(this, CalculatorActivity.class);
                startActivity(cIntent);
                break;

            case R.id.nav_more:
                Intent dIntent = new Intent(this, MoreActivity.class);
                startActivity(dIntent);
                break;

            case R.id.nav_settings:
                Intent eIntent = new Intent(this, SettingsActivity.class);
                startActivity(eIntent);
                break;
        }

        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

}