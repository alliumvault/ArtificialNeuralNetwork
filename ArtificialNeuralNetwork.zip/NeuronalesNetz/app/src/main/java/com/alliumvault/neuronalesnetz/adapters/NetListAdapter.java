package com.alliumvault.neuronalesnetz.adapters;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.alliumvault.neuronalesnetz.CustomTestActivity;
import com.alliumvault.neuronalesnetz.R;

import java.util.ArrayList;

public class NetListAdapter extends RecyclerView.Adapter<NetListAdapter.ViewHolder> {

    private final ArrayList<String> localTitle;
    private final Context context;

    public NetListAdapter(ArrayList<String> title, Context mContext) {
        localTitle = title;
        context = mContext;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.net_list_item, viewGroup, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, final int position) {

        viewHolder.getTitleView().setText(localTitle.get(position));

        viewHolder.getCardView().setOnClickListener(v -> {
            SharedPreferences newLocationSharedPreferences = context.getSharedPreferences("net_list", Context.MODE_PRIVATE);
            newLocationSharedPreferences.edit().putString("selectedItem", localTitle.get(position)).apply();
            context.startActivity(new Intent(context, CustomTestActivity.class));
        });
    }


    @Override
    public int getItemCount() {
        return localTitle.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView textViewTitle;
        private final CardView cardView;

        public ViewHolder(View view) {
            super(view);
            textViewTitle = view.findViewById(R.id.title_txt);
            cardView = view.findViewById(R.id.card_view);
        }

        public TextView getTitleView() {
            return textViewTitle;
        }

        public CardView getCardView() {
            return cardView;
        }
    }
}
