package com.alliumvault.neuronalesnetz.starters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.ImageView;

import androidx.annotation.RequiresApi;

import com.alliumvault.neuronalesnetz.models.Digit;
import com.alliumvault.neuronalesnetz.strandardnet.NeuralNetwork;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FileManager {
    private static final List<Digit> digits = new ArrayList<>();

    public static List<Digit> loadDataSet() {
        File sdCard = Environment.getExternalStorageDirectory();
        File dir = new File(sdCard.getAbsolutePath() + "/ImagesKNN");
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inPreferredConfig = Bitmap.Config.ARGB_8888;
                Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());

                float[][] pixels = new float[28][28];
                for (int i = 0; i < 28; i++) {
                    for (int k = 0; k < 28; k++) {

                        int pixel = bitmap.getPixel(i, k);

                        // extract each color component
                        int red = (pixel >>> 16) & 0xFF;
                        int green = (pixel >>> 8) & 0xFF;
                        int blue = (pixel) & 0xFF;

                        // calc luminance in range 0.0 to 1.0; using SRGB luminance constants
                        float luminance = (red * 0.2126f + green * 0.7152f + blue * 0.0722f) / 255;

                        if (luminance == 1.0) {
                            pixels[i][k] = (float) 0.0;
                        } else {
                            pixels[i][k] = (float) 0.9;
                        }

                        pixels[i][k] = (float) luminance;
                    }
                }

                String test = file.getName();
                String number = test.substring(test.lastIndexOf("_") + 1);
                char firstChar = number.charAt(0);
                digits.add(new Digit(Integer.parseInt(String.valueOf(firstChar)), pixels));
            }
        }
        return digits;
    }

    public static List<Digit> loadCustomDataSet(String networkTitle, int res) {
        File sdCard = Environment.getExternalStorageDirectory();
        File dir = new File(sdCard.getAbsolutePath() + "/" + networkTitle);
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inPreferredConfig = Bitmap.Config.ARGB_8888;
                Bitmap unscaledBitmap = BitmapFactory.decodeFile(file.getAbsolutePath());

                Bitmap bitmap = Bitmap.createScaledBitmap(unscaledBitmap, res, res, false);

                float[][] pixels = new float[res][res];
                for (int i = 0; i < res; i++) {
                    for (int k = 0; k < res; k++) {

                        int pixel = bitmap.getPixel(i, k);

                        // extract each color component
                        int red = (pixel >>> 16) & 0xFF;
                        int green = (pixel >>> 8) & 0xFF;
                        int blue = (pixel) & 0xFF;

                        // calc luminance in range 0.0 to 1.0; using SRGB luminance constants
                        float luminance = (red * 0.2126f + green * 0.7152f + blue * 0.0722f) / 255;

                        if (luminance == 1.0) {
                            pixels[i][k] = (float) 0.0;
                        } else {
                            pixels[i][k] = (float) 0.9;
                        }

                        pixels[i][k] = (float) luminance;
                    }
                }

                String test = file.getName();
                String number = test.substring(test.lastIndexOf("_") + 1);
                char firstChar = number.charAt(0);
                Log.d("ss", firstChar + ".");
                digits.add(new Digit(Integer.parseInt(String.valueOf(firstChar)), pixels));
            }
        }
        return digits;
    }

    public static Digit getDigitOfCategory(String category, String networkTitle, int res) {
        File sdCard = Environment.getExternalStorageDirectory();
        File subDir = new File(sdCard.getAbsolutePath() + "/" + networkTitle + "/" + category);
        File[] files = subDir.listFiles();
        if (files != null) {
            int index = (int) (Math.random() * files.length);

            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap unscaledBitmap = BitmapFactory.decodeFile(files[index].getAbsolutePath());

            Bitmap bitmap = Bitmap.createScaledBitmap(unscaledBitmap, res, res, false);

            float[][] pixels = new float[res][res];
            for (int i = 0; i < res; i++) {
                for (int k = 0; k < res; k++) {

                    int pixel = bitmap.getPixel(i, k);

                    // extract each color component
                    int red = (pixel >>> 16) & 0xFF;
                    int green = (pixel >>> 8) & 0xFF;
                    int blue = (pixel) & 0xFF;

                    // calc luminance in range 0.0 to 1.0; using SRGB luminance constants
                    float luminance = (red * 0.2126f + green * 0.7152f + blue * 0.0722f) / 255;

                    // if (luminance == 1.0) {
                    //     pixels[i][k] = (float) 0.0;
                    // } else {
                    //     pixels[i][k] = (float) 0.9;
                    // }

                    pixels[i][k] = (float) luminance;
                }
            }

            String test = files[index].getName();
            String number = "1";//test.substring(test.lastIndexOf("_") + 1);
            char firstChar = number.charAt(0);
            return new Digit(Integer.parseInt(String.valueOf(firstChar)), pixels);

        } else {
            return null;
        }
    }

    public static Digit getColorDigitOfCategory(String category, String networkTitle, int res) {
        File sdCard = Environment.getExternalStorageDirectory();
        File subDir = new File(sdCard.getAbsolutePath() + "/" + networkTitle + "/" + category);
        File[] files = subDir.listFiles();
        if (files != null) {
            int index = (int) (Math.random() * files.length);

            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap unscaledBitmap = BitmapFactory.decodeFile(files[index].getAbsolutePath());
            Bitmap bitmap = Bitmap.createScaledBitmap(unscaledBitmap, res, res, false);


            float[][] pixels = new float[res][res * 3];
            for (int i = 0; i < res; i++) {
                for (int k = 0; k < res; k++) {

                    int pixel = bitmap.getPixel(i, k);

                    // extract each color component
                    int red = (pixel >>> 16) & 0xFF;
                    int green = (pixel >>> 8) & 0xFF;
                    int blue = (pixel) & 0xFF;

                    // calc luminance in range 0.0 to 1.0; using SRGB luminance constants
                    float luminance = (red * 0.2126f + green * 0.7152f + blue * 0.0722f) / 255;


                    pixels[i][k] = (float) red / 255;
                    pixels[i][k + 1] = (float) green / 255;
                    pixels[i][k + 2] = (float) blue / 255;

                    k++;
                    k++;
                }
            }

            String test = files[index].getName();
            String number = "1";//test.substring(test.lastIndexOf("_") + 1);
            char firstChar = number.charAt(0);
            return new Digit(Integer.parseInt(String.valueOf(firstChar)), pixels);

        } else {
            return null;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static Digit getRandomDigitOfCategory(String category, String networkTitle, int res, ImageView imageView) {
        File sdCard = Environment.getExternalStorageDirectory();
        File subDir = new File(sdCard.getAbsolutePath() + "/" + networkTitle + "/" + category);
        File[] files = subDir.listFiles();
        if (files != null) {
            int index = (int) (Math.random() * files.length);

            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap unscaledBitmap = BitmapFactory.decodeFile(files[index].getAbsolutePath());
            Bitmap bitmap = Bitmap.createScaledBitmap(unscaledBitmap, res, res, false);

            float[][] pixels = new float[res][res];
            for (int i = 0; i < res; i++) {
                for (int k = 0; k < res; k++) {

                    int pixel = bitmap.getPixel(i, k);

                    // extract each color component
                    int red = (pixel >>> 16) & 0xFF;
                    int green = (pixel >>> 8) & 0xFF;
                    int blue = (pixel) & 0xFF;

                    // calc luminance in range 0.0 to 1.0; using SRGB luminance constants
                    float luminance = (red * 0.2126f + green * 0.7152f + blue * 0.0722f) / 255;

                    pixels[i][k] = (float) luminance;


                    bitmap.setPixel(i, k, Color.rgb((float) luminance, (float) luminance, (float) luminance));
                }
            }


            Handler handler = new Handler(Looper.getMainLooper());
            handler.post(() -> imageView.setImageBitmap(bitmap));


            return new Digit(1, pixels);

        } else {
            return null;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static Digit getRandomColorDigitOfCategory(String category, String networkTitle, int res, ImageView imageView) {
        File sdCard = Environment.getExternalStorageDirectory();
        File subDir = new File(sdCard.getAbsolutePath() + "/" + networkTitle + "/" + category);
        File[] files = subDir.listFiles();
        if (files != null) {
            int index = (int) (Math.random() * files.length);

            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap unscaledBitmap = BitmapFactory.decodeFile(files[index].getAbsolutePath());
            Bitmap bitmap = Bitmap.createScaledBitmap(unscaledBitmap, res, res, false);

            float[][] pixels = new float[res][res * 3];
            for (int i = 0; i < res; i++) {
                for (int k = 0; k < res; k++) {

                    int pixel = bitmap.getPixel(i, k);

                    // extract each color component
                    int red = (pixel >>> 16) & 0xFF;
                    int green = (pixel >>> 8) & 0xFF;
                    int blue = (pixel) & 0xFF;

                    // calc luminance in range 0.0 to 1.0; using SRGB luminance constants
                    float luminance = (red * 0.2126f + green * 0.7152f + blue * 0.0722f) / 255;

                    pixels[i][k] = (float) red / 255;
                    pixels[i][k + 1] = (float) green / 255;
                    pixels[i][k + 2] = (float) blue / 255;

                    k++;
                    k++;

                    Log.d("ss", (float) red / 255 + " | " + (float) green / 255 + " | " + (float) (blue) / 255 + " (rgb)");

                    /*
                    pixels[i][k] = (float) (red) / 255;
                    pixels[i][k + 1] = (float) (green) / 255;
                    pixels[i][k + 2] = (float) (blue) / 255;

                    k++;
                    k++;

                    Log.d("ss", (red) / 255 + " | " + (green) / 255 + " | " + (blue) / 255 + " (rgb)");
                     */
                }
            }


            Handler handler = new Handler(Looper.getMainLooper());
            handler.post(() -> imageView.setImageBitmap(bitmap));


            return new Digit(1, pixels);

        } else {
            return null;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static Digit getRandomDigit(String networkTitle, int res, ImageView imageView) {
        File sdCard = Environment.getExternalStorageDirectory();
        File subDir = new File(sdCard.getAbsolutePath() + "/" + networkTitle);
        File[] files = subDir.listFiles();
        if (files != null) {
            int index = (int) (Math.random() * files.length);

            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap unscaledBitmap = BitmapFactory.decodeFile(files[index].getAbsolutePath());
            Bitmap bitmap = Bitmap.createScaledBitmap(unscaledBitmap, res, res, false);

            float[][] pixels = new float[res][res];
            for (int i = 0; i < res; i++) {
                for (int k = 0; k < res; k++) {

                    int pixel = bitmap.getPixel(i, k);

                    // extract each color component
                    int red = (pixel >>> 16) & 0xFF;
                    int green = (pixel >>> 8) & 0xFF;
                    int blue = (pixel) & 0xFF;

                    // calc luminance in range 0.0 to 1.0; using SRGB luminance constants
                    float luminance = (red * 0.2126f + green * 0.7152f + blue * 0.0722f) / 255;

                    pixels[i][k] = (float) luminance;


                    bitmap.setPixel(i, k, Color.rgb((float) luminance, (float) luminance, (float) luminance));
                }
            }


            Handler handler = new Handler(Looper.getMainLooper());
            handler.post(() -> imageView.setImageBitmap(bitmap));


            return new Digit(1, pixels);

        } else {
            return null;
        }
    }

    public static Digit getDigitOfCategoryWithIndex(String category, String networkTitle, int res, int index) {
        File sdCard = Environment.getExternalStorageDirectory();
        File subDir = new File(sdCard.getAbsolutePath() + "/" + networkTitle + "/" + category);
        File[] files = subDir.listFiles();
        if (files != null) {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap unscaledBitmap = BitmapFactory.decodeFile(files[index].getAbsolutePath());
            Bitmap bitmap = Bitmap.createScaledBitmap(unscaledBitmap, res, res, false);

            float[][] pixels = new float[res][res];
            for (int i = 0; i < res; i++) {
                for (int k = 0; k < res; k++) {

                    int pixel = bitmap.getPixel(i, k);

                    // extract each color component
                    int red = (pixel >>> 16) & 0xFF;
                    int green = (pixel >>> 8) & 0xFF;
                    int blue = (pixel) & 0xFF;

                    // calc luminance in range 0.0 to 1.0; using SRGB luminance constants
                    float luminance = (red * 0.2126f + green * 0.7152f + blue * 0.0722f) / 255;

                    // if (luminance == 1.0) {
                    //     pixels[i][k] = (float) 0.0;
                    // } else {
                    //     pixels[i][k] = (float) 0.9;
                    // }

                    pixels[i][k] = (float) luminance;
                }
            }

            String test = files[index].getName();
            String number = "1";//test.substring(test.lastIndexOf("_") + 1);
            char firstChar = number.charAt(0);
            return new Digit(Integer.parseInt(String.valueOf(firstChar)), pixels);

        } else {
            return null;
        }
    }

    public static List<Digit> getTestData() {
        File sdCard = Environment.getExternalStorageDirectory();
        File dir = new File(sdCard.getAbsolutePath() + "/ImagesKNNW/test");
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inPreferredConfig = Bitmap.Config.ARGB_8888;
                Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());

                float[][] pixels = new float[28][28];
                for (int i = 0; i < 28; i++) {
                    for (int k = 0; k < 28; k++) {

                        int pixel = bitmap.getPixel(i, k);

                        // extract each color component
                        int red = (pixel >>> 16) & 0xFF;
                        int green = (pixel >>> 8) & 0xFF;
                        int blue = (pixel) & 0xFF;

                        // calc luminance in range 0.0 to 1.0; using SRGB luminance constants
                        float luminance = (red * 0.2126f + green * 0.7152f + blue * 0.0722f) / 255;

                        if (luminance == 1.0) {
                            pixels[i][k] = (float) 0.0;
                        } else {
                            // pixels[i][k] = luminance;
                            pixels[i][k] = (float) 0.9;
                        }

                        pixels[i][k] = (float) luminance;

                    }
                }

                String test = file.getName();
                String number = test.substring(test.lastIndexOf("_") + 1);
                char firstChar = number.charAt(0);
                digits.add(new Digit(Integer.parseInt(String.valueOf(firstChar)), pixels));
            }
        }
        return digits;
    }

    public static void setLearningStatus(String name, boolean shouldLearn) throws IOException {
        File sdCard = Environment.getExternalStorageDirectory();
        File dir = new File(sdCard.getAbsolutePath() + "/" + name + "W");
        dir.mkdirs();
        File weightsFile = new File(dir, "learningStatus" + ".status");

        FileWriter myWriter = new FileWriter(weightsFile);
        myWriter.write("" + shouldLearn);
        myWriter.close();
    }

    public static boolean getLearningStatus(String name) throws IOException {
        File sdCard = Environment.getExternalStorageDirectory();
        File dir = new File(sdCard.getAbsolutePath() + "/" + name + "W");
        dir.mkdirs();
        File weightsFile = new File(dir, "learningStatus" + ".status");

        Scanner myReader = new Scanner(weightsFile);
        String data = myReader.nextLine();
        return data.trim().equals("true");
    }

    public static void addDigit(Bitmap bitmap, int label, int res, String title) {
        Bitmap bitmapScaled = Bitmap.createScaledBitmap(bitmap, res, res, false);

        File sdCard = Environment.getExternalStorageDirectory();
        File dir = new File(sdCard.getAbsolutePath() + "/" + title);
        dir.mkdirs();
        File file = new File(dir, System.currentTimeMillis() + "_" + label + ".png");


        try (FileOutputStream out = new FileOutputStream(file)) {
            bitmapScaled.compress(Bitmap.CompressFormat.PNG, 100, out);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Digit getDigit(Bitmap b, int label) {
        Bitmap bitmapScaled = Bitmap.createScaledBitmap(b, 28, 28, false);
        float[][] pixels = new float[28][28];
        for (int i = 0; i < 28; i++) {
            for (int k = 0; k < 28; k++) {

                int pixel = bitmapScaled.getPixel(i, k);

                int red = (pixel >>> 16) & 0xFF;
                int green = (pixel >>> 8) & 0xFF;
                int blue = (pixel) & 0xFF;

                float luminance = (red * 0.2126f + green * 0.7152f + blue * 0.0722f) / 255;
                if (luminance == 1.0) {
                    pixels[i][k] = (float) 0.0;
                } else {
                    pixels[i][k] = pixels[i][k] = (float) 0.9;
                }

                pixels[i][k] = (float) 1.0 - luminance;
            }
        }

        return new Digit(label, pixels);
    }

    public static Digit getCustomDigit(Bitmap b, int label, int size) {
        Bitmap bitmapScaled = Bitmap.createScaledBitmap(b, size, size, false);
        float[][] pixels = new float[size][size];
        for (int i = 0; i < size; i++) {
            for (int k = 0; k < size; k++) {

                int pixel = bitmapScaled.getPixel(i, k);

                int red = (pixel >>> 16) & 0xFF;
                int green = (pixel >>> 8) & 0xFF;
                int blue = (pixel) & 0xFF;

                float luminance = (red * 0.2126f + green * 0.7152f + blue * 0.0722f) / 255;
                if (luminance == 1.0) {
                    pixels[i][k] = (float) 0.0;
                } else {
                    pixels[i][k] = pixels[i][k] = (float) 0.9;
                }

                pixels[i][k] = (float) luminance;
            }
        }

        return new Digit(label, pixels);
    }

    public static float[] getSymbolWeights(Context context) throws IOException, ClassNotFoundException {
        InputStream fis = context.getAssets().open("symbols.weights");

        ObjectInputStream in = new ObjectInputStream(fis);
        float[] weights = (float[]) in.readObject();
        in.close();

        return weights;
    }

    public static float[] getNumWeights(Context context) throws IOException, ClassNotFoundException {
        InputStream fis = context.getAssets().open("num.weights");

        ObjectInputStream in = new ObjectInputStream(fis);
        float[] weights = (float[]) in.readObject();
        in.close();

        return weights;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static float[] getCustomWeights(String netName) throws IOException, ClassNotFoundException {
        File sdCard = Environment.getExternalStorageDirectory();
        File dir = new File(sdCard.getAbsolutePath() + "/" + netName + "W");
        dir.mkdirs();
        File file = new File(dir, "weights");
        file.mkdirs();
        File weightsFile = new File(file, "num" + ".weights");

        InputStream fis = Files.newInputStream(Paths.get(weightsFile.getPath()));

        ObjectInputStream in = new ObjectInputStream(fis);
        float[] weights = (float[]) in.readObject();
        in.close();

        return weights;
    }

    public static void saveCustomWeights(NeuralNetwork net, int numHidden, int res, int numOut, String netName) throws IOException {
        File sdCard = Environment.getExternalStorageDirectory();
        File dir = new File(sdCard.getAbsolutePath() + "/" + netName + "W");
        dir.mkdirs();
        File file = new File(dir, "weights");
        file.mkdirs();
        File weightsFile = new File(file, "num" + ".weights");

        ObjectOutputStream out = new ObjectOutputStream(
                new FileOutputStream(weightsFile)
        );
        out.writeObject(net.getWeights(numHidden, numOut, res));
        out.flush();
        out.close();
    }


    public static void saveCustomHiddenTwoWeights(NeuralNetwork net, int numHidden, int res, int numOut, String netName, int numHiddenTwo) throws IOException {
        File sdCard = Environment.getExternalStorageDirectory();
        File dir = new File(sdCard.getAbsolutePath() + "/" + netName + "W");
        dir.mkdirs();
        File file = new File(dir, "weights");
        file.mkdirs();
        File weightsFile = new File(file, "num" + ".weights");

        ObjectOutputStream out = new ObjectOutputStream(
                new FileOutputStream(weightsFile)
        );
        out.writeObject(net.getHiddenTwoWeights(numHidden, numOut, res, numHiddenTwo));
        out.flush();
        out.close();
    }

    public static void saveCustomHiddenTwoColorWeights(NeuralNetwork net, int numHidden, int res, int numOut, String netName, int numHiddenTwo) throws IOException {
        File sdCard = Environment.getExternalStorageDirectory();
        File dir = new File(sdCard.getAbsolutePath() + "/" + netName + "W");
        dir.mkdirs();
        File file = new File(dir, "weights");
        file.mkdirs();
        File weightsFile = new File(file, "num" + ".weights");

        ObjectOutputStream out = new ObjectOutputStream(
                new FileOutputStream(weightsFile)
        );
        out.writeObject(net.getColorHiddenTwoWeights(numHidden, numOut, res, numHiddenTwo));
        out.flush();
        out.close();
    }

    public static void saveCustomColorWeights(NeuralNetwork net, int numHidden, int res, int numOut, String netName) throws IOException {
        File sdCard = Environment.getExternalStorageDirectory();
        File dir = new File(sdCard.getAbsolutePath() + "/" + netName + "W");
        dir.mkdirs();
        File file = new File(dir, "weights");
        file.mkdirs();
        File weightsFile = new File(file, "num" + ".weights");

        ObjectOutputStream out = new ObjectOutputStream(
                new FileOutputStream(weightsFile)
        );
        out.writeObject(net.getColorWeights(numHidden, numOut, res));
        out.flush();
        out.close();
    }

    public static void saveNumWeights(NeuralNetwork net, int numHidden, int res) throws IOException {
        File sdCard = Environment.getExternalStorageDirectory();
        File dir = new File(sdCard.getAbsolutePath() + "/ImagesKNNW");
        dir.mkdirs();
        File file = new File(dir, "weights");
        file.mkdirs();
        File weightsFile = new File(file, "num" + ".weights");

        ObjectOutputStream out = new ObjectOutputStream(
                new FileOutputStream(weightsFile)
        );
        out.writeObject(net.getWeights(numHidden, 10, res));
        out.flush();
        out.close();
    }

    public static void saveSymbolWeights(NeuralNetwork net, int numHidden, int res) throws IOException {
        File sdCard = Environment.getExternalStorageDirectory();
        File dir = new File(sdCard.getAbsolutePath() + "/ImagesKNNW");
        dir.mkdirs();
        File file = new File(dir, "weights");
        file.mkdirs();
        File weightsFile = new File(file, "symbols" + ".weights");

        ObjectOutputStream out = new ObjectOutputStream(
                new FileOutputStream(weightsFile)
        );
        out.writeObject(net.getWeights(numHidden, 4, res));
        out.flush();
        out.close();
    }
}
