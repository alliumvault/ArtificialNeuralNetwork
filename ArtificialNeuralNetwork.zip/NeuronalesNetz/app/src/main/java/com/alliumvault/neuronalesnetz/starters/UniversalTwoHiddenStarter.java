package com.alliumvault.neuronalesnetz.starters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;

import com.alliumvault.neuronalesnetz.models.Digit;
import com.alliumvault.neuronalesnetz.models.ProbabilityDigit;
import com.alliumvault.neuronalesnetz.strandardnet.InputNeuron;
import com.alliumvault.neuronalesnetz.strandardnet.NeuralNetwork;
import com.alliumvault.neuronalesnetz.strandardnet.WorkingNeuron;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class UniversalTwoHiddenStarter {
    static NeuralNetwork nn = new NeuralNetwork();
    static List<Digit> digits;
    static List<Digit> testDigits;
    static InputNeuron[][] inputs;
    static WorkingNeuron[] outputs;


    public static void startLearning(TextView uni, int res, int numHiddenNeurons, int numHiddenTwo,
                                     int numOutputs, String networkTitle) throws IOException {

        inputs = new InputNeuron[res][res];
        outputs = new WorkingNeuron[numOutputs];

        digits = FileManager.loadCustomDataSet(networkTitle, res);
        testDigits = FileManager.loadCustomDataSet(networkTitle, res); //extraTestSet!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

        for (int i = 0; i < res; i++) {
            for (int k = 0; k < res; k++) {
                inputs[i][k] = nn.createNewInput();
            }
        }

        for (int i = 0; i < numOutputs; i++) {
            outputs[i] = nn.createNewOutput();
        }

        nn.createHiddenNeurons(numHiddenNeurons);


        ///////////////////////////////////////////////////////////////////////


        nn.createHiddenNeuronsTwo(numHiddenTwo);

        ///////////////////////////////////////////////////////////////////////


        Random rand = new Random();
        float[] weights = new float[(res * res) * numHiddenNeurons + numHiddenNeurons *
                numHiddenTwo + numHiddenTwo * numOutputs];
        for (int i = 0; i < weights.length; i++) {
            weights[i] = rand.nextFloat();
        }

        nn.createFullMesh(weights);

        Handler mHandler = new Handler(Looper.getMainLooper());
        mHandler.post(() -> uni.setText("10%"));


        float epsilon = 0.005f;
        while (FileManager.getLearningStatus(networkTitle)) {
            for (int i = 0; i < digits.size(); i++) {
                for (int x = 0; x < res; x++) {
                    for (int y = 0; y < res; y++) {
                        inputs[x][y].setValue(digits.get(i).data[x][y]);
                    }
                }

                float[] shoulds = new float[numOutputs];
                shoulds[digits.get(i).label] = 1;
                nn.backpropagation(shoulds, epsilon);
            }
            epsilon *= 0.99;
            testProgress(uni, numOutputs, res);
            try {
                FileManager.saveCustomHiddenTwoWeights(nn, numHiddenNeurons, res,
                        numOutputs, networkTitle, numHiddenTwo);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(() -> uni.append(" (done)"));
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static void startLearningWithOtherDataSet(TextView uni, int res, int numHiddenNeurons, int numHiddenTwo, int numOutputs,
                                                     ArrayList<String> categories, String networkTitle,
                                                     ImageView tstImage, TextView txtResult) throws IOException {

        inputs = new InputNeuron[res][res];
        outputs = new WorkingNeuron[numOutputs];

        for (int i = 0; i < res; i++) {
            for (int k = 0; k < res; k++) {
                inputs[i][k] = nn.createNewInput();
            }
        }

        for (int i = 0; i < numOutputs; i++) {
            outputs[i] = nn.createNewOutput();
        }

        nn.createHiddenNeurons(numHiddenNeurons);


        ///////////////////////////////////////////////////////////////////////


        nn.createHiddenNeuronsTwo(numHiddenTwo);

        ///////////////////////////////////////////////////////////////////////


        Random rand = new Random();
        float[] weights = new float[(res * res) * numHiddenNeurons + numHiddenNeurons * numHiddenTwo + numHiddenTwo * numOutputs];
        for (int i = 0; i < weights.length; i++) {
            weights[i] = rand.nextFloat();
        }

        nn.createFullMesh(weights);

        Handler mHandler = new Handler(Looper.getMainLooper());
        mHandler.post(() -> uni.setText("10%"));


        float epsilon = 0.00005f;
        while (FileManager.getLearningStatus(networkTitle)) {
            Log.d("sss", "next started");
            testRandomImage(txtResult, tstImage, numOutputs, res, networkTitle, categories);
            testOtherDataSetProgress(uni, numOutputs, res, networkTitle, categories);
            int c = 0;
            while (c < 50) {
                for (int i = 0; i < categories.size(); i++) {

                    Digit currentDigit = FileManager.getDigitOfCategory(categories.get(i), networkTitle, res);
                    for (int x = 0; x < res; x++) {
                        for (int y = 0; y < res; y++) {
                            inputs[x][y].setValue(currentDigit.data[x][y]);
                        }
                    }

                    float[] shoulds = new float[numOutputs];
                    shoulds[i] = 1;
                    nn.backpropagation(shoulds, epsilon);
                    Log.d("ss", i + "...");
                }
                c++;
            }
            epsilon *= 0.99;
            try {
                FileManager.saveCustomHiddenTwoWeights(nn, numHiddenNeurons, res, numOutputs, networkTitle, numHiddenTwo);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(() -> uni.append(" (done)"));
    }

    private static void testOtherDataSetProgress(TextView uni, int numOut, int res, String netName, ArrayList<String> categories) {
        int correct = 0;
        int incorrect = 0;
        int c = 0;
        while (c < 20) {


            for (int i = 0; i < categories.size(); i++) {
                nn.resetHiddenTwo();
                Digit currentDigit = FileManager.getDigitOfCategory(categories.get(i), netName, res);
                for (int x = 0; x < res; x++) {
                    for (int y = 0; y < res; y++) {
                        inputs[x][y].setValue(currentDigit.data[x][y]);
                    }
                }


                ProbabilityDigit[] probabilityDigits = new ProbabilityDigit[numOut];
                for (int k = 0; k < probabilityDigits.length; k++) {
                    probabilityDigits[k] = new ProbabilityDigit(k, outputs[k].getValue());
                    Log.d("sss", "Connections" + k + ": " + outputs[k].getValue());
                }

                Arrays.sort(probabilityDigits, Collections.reverseOrder());

                if (i == probabilityDigits[0].DIGIT) {
                    Log.d("sss", "was correct");
                    correct++;
                } else {
                    Log.d("sss", "was not correct");
                    incorrect++;
                }
                c++;
            }
        }

        float percentage = (float) correct / (float) (correct + incorrect);
        Log.d("sss", "percentage: " + percentage * 100);

        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(() -> uni.setText(percentage * 100 + "%"));
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static void startLearningWithColorOtherDataSet(TextView uni, int res, int numHiddenNeurons,
                                                          int numHiddenTwo, int numOutputs,
                                                          ArrayList<String> categories, String networkTitle,
                                                          ImageView tstImage, TextView txtResult) throws IOException {

        inputs = new InputNeuron[res][res * 3];
        outputs = new WorkingNeuron[numOutputs];

        for (int i = 0; i < res; i++) {
            for (int k = 0; k < res * 3; k++) {
                inputs[i][k] = nn.createNewInput();
            }
        }

        for (int i = 0; i < numOutputs; i++) {
            outputs[i] = nn.createNewOutput();
        }

        nn.createHiddenNeurons(numHiddenNeurons);


        ///////////////////////////////////////////////////////////////////////


        nn.createHiddenNeuronsTwo(numHiddenTwo);

        ///////////////////////////////////////////////////////////////////////


        Random rand = new Random();
        float[] weights = new float[((res * res) * 3) * numHiddenNeurons + numHiddenNeurons * numHiddenTwo + numHiddenTwo * numOutputs];
        for (int i = 0; i < weights.length; i++) {
            weights[i] = rand.nextFloat();
        }

        nn.createFullMesh(weights);

        Handler mHandler = new Handler(Looper.getMainLooper());
        mHandler.post(() -> uni.setText("10%"));


        float epsilon = 0.005f;
        while (FileManager.getLearningStatus(networkTitle)) {
            Log.d("sss", "next started");
            testOtherColorDataSetProgress(uni, numOutputs, res, networkTitle, categories);
            testRandomColorImage(txtResult, tstImage, numOutputs, res, networkTitle, categories);
            int c = 0;
            while (c < 50) {
                for (int i = 0; i < categories.size(); i++) {

                    Digit currentDigit = FileManager.getColorDigitOfCategory(categories.get(i), networkTitle, res);
                    for (int x = 0; x < res; x++) {
                        for (int y = 0; y < res * 3; y++) {
                            inputs[x][y].setValue(currentDigit.data[x][y]);
                            inputs[x][y + 1].setValue(currentDigit.data[x][y + 1]);
                            inputs[x][y + 2].setValue(currentDigit.data[x][y + 2]);
                            y++;
                            y++;
                        }
                    }

                    float[] shoulds = new float[numOutputs];
                    shoulds[i] = 1;
                    nn.backpropagation(shoulds, epsilon);
                    Log.d("ss", i + "...");
                }
                c++;
            }
            epsilon *= 0.99;

            try {
                FileManager.saveCustomHiddenTwoColorWeights(nn, numHiddenNeurons, res, numOutputs, networkTitle, numHiddenTwo);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(() -> uni.append(" (done)"));
    }

    private static void testOtherColorDataSetProgress(TextView uni, int numOut, int res, String netName, ArrayList<String> categories) {
        int correct = 0;
        int incorrect = 0;
        int c = 0;
        while (c < 20) {


            for (int i = 0; i < categories.size(); i++) {
                nn.resetHiddenTwo();
                Digit currentDigit = FileManager.getColorDigitOfCategory(categories.get(i), netName, res);
                for (int x = 0; x < res; x++) {
                    for (int y = 0; y < res * 3; y++) {
                        inputs[x][y].setValue(currentDigit.data[x][y]);
                        inputs[x][y + 1].setValue(currentDigit.data[x][y + 1]);
                        inputs[x][y + 2].setValue(currentDigit.data[x][y + 2]);
                        y++;
                        y++;
                    }
                }


                ProbabilityDigit[] probabilityDigits = new ProbabilityDigit[numOut];
                for (int k = 0; k < probabilityDigits.length; k++) {
                    probabilityDigits[k] = new ProbabilityDigit(k, outputs[k].getValue());
                    Log.d("sss", "Connections" + k + ": " + outputs[k].getValue());
                }

                Arrays.sort(probabilityDigits, Collections.reverseOrder());

                if (i == probabilityDigits[0].DIGIT) {
                    Log.d("sss", "was correct");
                    correct++;
                } else {
                    Log.d("sss", "was not correct");
                    incorrect++;
                }
                c++;
            }
        }

        float percentage = (float) correct / (float) (correct + incorrect);
        Log.d("sss", "percentage: " + percentage * 100);

        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(() -> uni.setText(percentage * 100 + "%"));
    }



    @RequiresApi(api = Build.VERSION_CODES.O)
    private static void testRandomImage(TextView result, ImageView tstImage, int numOut, int res, String netName, ArrayList<String> categories) {
        nn.resetHiddenTwo();

        int index = (int) (Math.random() * categories.size());

        Digit currentDigit = FileManager.getRandomDigitOfCategory(categories.get(index), netName, res, tstImage);
        for (int x = 0; x < res; x++) {
            for (int y = 0; y < res; y++) {
                inputs[x][y].setValue(currentDigit.data[x][y]);
            }
        }


        ProbabilityDigit[] probabilityDigits = new ProbabilityDigit[numOut];
        for (int k = 0; k < probabilityDigits.length; k++) {
            probabilityDigits[k] = new ProbabilityDigit(k, outputs[k].getValue());
        }

        Arrays.sort(probabilityDigits, Collections.reverseOrder());

        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(() -> result.setText(categories.get(probabilityDigits[0].DIGIT)));
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static void testRandomImageExtern(TextView result, ImageView tstImage, int numOut, int res, String netName, ArrayList<String> categories) {
        nn.resetHiddenTwo();

        int index = (int) (Math.random() * categories.size());

        Digit currentDigit = FileManager.getRandomDigitOfCategory(categories.get(index), netName, res, tstImage);
        //Digit currentDigit = FileManager.getRandomDigit(netName, res, tstImage);
        for (int x = 0; x < res; x++) {
            for (int y = 0; y < res; y++) {
                inputs[x][y].setValue(currentDigit.data[x][y]);
            }
        }


        ProbabilityDigit[] probabilityDigits = new ProbabilityDigit[numOut];
        for (int k = 0; k < probabilityDigits.length; k++) {
            probabilityDigits[k] = new ProbabilityDigit(k, outputs[k].getValue());
        }

        Arrays.sort(probabilityDigits, Collections.reverseOrder());

        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(() -> result.setText(categories.get(probabilityDigits[0].DIGIT)));
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private static void testRandomColorImage(TextView result, ImageView tstImage, int numOut, int res, String netName, ArrayList<String> categories) {
        nn.resetHiddenTwo();

        int index = (int) (Math.random() * categories.size());

        Digit currentDigit = FileManager.getRandomColorDigitOfCategory(categories.get(index), netName, res, tstImage);
        for (int x = 0; x < res; x++) {
            for (int y = 0; y < res * 3; y++) {
                inputs[x][y].setValue(currentDigit.data[x][y]);
                inputs[x][y + 1].setValue(currentDigit.data[x][y + 1]);
                inputs[x][y + 2].setValue(currentDigit.data[x][y + 2]);
                y++;
                y++;
            }
        }


        ProbabilityDigit[] probabilityDigits = new ProbabilityDigit[numOut];
        for (int k = 0; k < probabilityDigits.length; k++) {
            probabilityDigits[k] = new ProbabilityDigit(k, outputs[k].getValue());
        }

        Arrays.sort(probabilityDigits, Collections.reverseOrder());

        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(() -> result.setText(categories.get(probabilityDigits[0].DIGIT)));
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static void testRandomColorImageExtern(TextView result, ImageView tstImage, int numOut, int res, String netName, ArrayList<String> categories) {
        nn.resetHiddenTwo();

        int index = (int) (Math.random() * categories.size());

        Digit currentDigit = FileManager.getRandomColorDigitOfCategory(categories.get(index), netName, res, tstImage);
        //Digit currentDigit = FileManager.getRandomDigit(netName, res, tstImage);
        for (int x = 0; x < res; x++) {
            for (int y = 0; y < res * 3; y++) {
                inputs[x][y].setValue(currentDigit.data[x][y]);
                inputs[x][y + 1].setValue(currentDigit.data[x][y + 1]);
                inputs[x][y + 2].setValue(currentDigit.data[x][y + 2]);
                y++;
                y++;
            }
        }


        ProbabilityDigit[] probabilityDigits = new ProbabilityDigit[numOut];
        for (int k = 0; k < probabilityDigits.length; k++) {
            probabilityDigits[k] = new ProbabilityDigit(k, outputs[k].getValue());
        }

        Arrays.sort(probabilityDigits, Collections.reverseOrder());

        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(() -> result.setText(categories.get(probabilityDigits[0].DIGIT)));
    }

    private static void testProgress(TextView uni, int numOut, int res) {
        int correct = 0;
        int incorrect = 0;
        for (int i = 0; i < testDigits.size(); i++) {
            nn.resetHiddenTwo();
            for (int x = 0; x < res; x++) {
                for (int y = 0; y < res; y++) {
                    inputs[x][y].setValue(testDigits.get(i).data[x][y]);
                }
            }

            ProbabilityDigit[] probabilityDigits = new ProbabilityDigit[numOut];
            for (int k = 0; k < probabilityDigits.length; k++) {
                probabilityDigits[k] = new ProbabilityDigit(k, outputs[k].getValue());
                Log.d("sss", "Connections" + k + ": " + outputs[k].getValue());
            }

            Arrays.sort(probabilityDigits, Collections.reverseOrder());

            if (testDigits.get(i).label == probabilityDigits[0].DIGIT) {
                correct++;
            } else {
                incorrect++;
            }
        }

        float percentage = (float) correct / (float) (correct + incorrect);
        Log.d("sss", "percentage: " + percentage * 100);

        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(() -> uni.setText(percentage * 100 + "%"));
    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    public static void load(TextView uni, Context context, int res, int numHiddenTwo,
                            int numOut, int numHiddenNeurons, String netName) {

        inputs = new InputNeuron[res][res];
        outputs = new WorkingNeuron[numOut];

        for (int i = 0; i < res; i++) {
            for (int k = 0; k < res; k++) {
                inputs[i][k] = nn.createNewInput();
            }
        }

        for (int i = 0; i < numOut; i++) {
            outputs[i] = nn.createNewOutput();
        }

        nn.createHiddenNeurons(numHiddenNeurons);

        nn.createHiddenNeuronsTwo(numHiddenTwo);

        Log.d("GGGGGGGGGG", "res" + res);
        Log.d("GGGGGGGGGG", "numHiddenNeurons" + numHiddenNeurons);
        Log.d("GGGGGGGGGG", "numOut" + numOut);

        float[] weights = new float[res * res * numHiddenNeurons + numHiddenNeurons * numHiddenTwo + numHiddenTwo * numOut];

        try {
            float[] readWeights = FileManager.getCustomWeights(netName);
            if (readWeights.length == weights.length) {
                nn.createFullMesh(readWeights);
                Handler handler = new Handler(Looper.getMainLooper());
                handler.post(() -> uni.setText("loaded weights"));
            } else {
                Log.d("GGGGGGGGGG", readWeights.length + "I" + weights.length);
                throw new IllegalArgumentException();
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }


    }

    @SuppressLint("SetTextI18n")
    public static int test(Digit d, Context mContext, TextView result1Text, TextView
            result2Text, TextView result3Text, int res, int numOut) {
        nn.resetHiddenTwo();
        for (int x = 0; x < res; x++) {
            for (int y = 0; y < res; y++) {
                inputs[x][y].setValue(d.data[x][y]);
            }
        }

        ProbabilityDigit[] probs = new ProbabilityDigit[numOut];
        for (int k = 0; k < probs.length; k++) {
            probs[k] = new ProbabilityDigit(k, outputs[k].getValue());
            //Log.d("sss", "Connections" + k + ": " + outputs[k].getValue());
        }

        Arrays.sort(probs, Collections.reverseOrder());


        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(() -> {
            //if (probs[0].probability > 0.5) {
            //    result1Text.setText(probs[0].DIGIT + "  (" + probs[0].probability * 100 + "%)");
            //} else {
            //    result1Text.setText(probs[0].DIGIT + "  (" + probs[0].probability * 100 + "%)  --> UNSICHER");
            //}
            //result2Text.setText(probs[1].DIGIT + "  (" + probs[1].probability * 100 + "%)");
            //result3Text.setText(probs[2].DIGIT + "  (" + probs[2].probability + 100 + "%)");

            result1Text.setText(probs[0].DIGIT + "  (" + probs[0].probability * 100 + "%)");
        });

        return probs[0].DIGIT;
    }

}
