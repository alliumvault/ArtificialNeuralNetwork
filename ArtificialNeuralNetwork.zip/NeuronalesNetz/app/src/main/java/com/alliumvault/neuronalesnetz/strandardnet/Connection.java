package com.alliumvault.neuronalesnetz.strandardnet;

import java.io.Serializable;

public class Connection implements Serializable {
    private final Neuron neuron;
    private float weight;
    private float momentum;
    private float weightAdd;

    public Connection(Neuron neuron, float weight) {
        this.neuron = neuron;
        this.weight = weight;
    }

    public float getValue() {
        return neuron.getValue() * weight;
    }

    public void addWeight(float weightDelta) {
        weightAdd += weightDelta;
    }

    public void applyBatch() {

        momentum += weightAdd;
        momentum *= 0.9;
        weight += momentum + weightAdd;

        weightAdd = 0;
    }

    public Neuron getNeuron() {
        return neuron;
    }

    public float getWeight() {
        return weight;
    }
}

