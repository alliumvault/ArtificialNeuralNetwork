package com.alliumvault.neuronalesnetz.models;


public class NetListModel {
    String title;
    String idName;

    public NetListModel() {
    }

    public NetListModel(String title, String idName) {
        this.title = title;
        this.idName = idName;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getIdName() {
        return idName;
    }

    public void setIdName(String idName) {
        this.idName = idName;
    }

}