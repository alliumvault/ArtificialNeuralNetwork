package com.alliumvault.neuronalesnetz.strandardnet;

import java.io.Serializable;

public class InputNeuron extends Neuron implements Serializable {

    private float value = 0;

    @Override
    public float getValue() {
        return value;
    }

    public void setValue(float value) {
        this.value = value;
    }
}
