package com.alliumvault.neuronalesnetz;


import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.alliumvault.neuronalesnetz.starters.FileManager;
import com.alliumvault.neuronalesnetz.starters.GAStarter;
import com.alliumvault.neuronalesnetz.starters.UniversalStarter;
import com.alliumvault.neuronalesnetz.starters.UniversalTwoHiddenStarter;
import com.google.android.material.navigation.NavigationView;

import java.io.IOException;
import java.util.ArrayList;

public class CustomOtherActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout drawer;
    NavigationView navigationView;

    TextView percentageText, resultTxt;
    Button btnStartStop, btnTestRandom;
    ImageView tstImage;

    boolean isLearning = false;

    ArrayList<String> categories = new ArrayList<>();

    int sc = 0;

    int res = 100;
    int numHidden = 200;
    int numHiddenTwo = 50;


    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_other);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.error, R.string.error);
        //noinspection deprecation
        drawer.setDrawerListener(toggle);
        toggle.syncState();
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        requestPermissions();

        percentageText = findViewById(R.id.percentage_text);
        btnStartStop = findViewById(R.id.btn_start_stop_learning);
        resultTxt = findViewById(R.id.result_txt);
        btnTestRandom = findViewById(R.id.btn_test_random_image);
        tstImage = findViewById(R.id.tst_image);

        categories.add("Forest");
        categories.add("Landscape");
        categories.add("Window");
        categories.add("Document");
        categories.add("Flower");

        btnTestRandom.setOnClickListener(v -> {

            if (sc == 0) {
                UniversalStarter.loadColor(resultTxt, CustomOtherActivity.this, res,
                        categories.size(),
                        numHidden,
                        "realImageTst");
            }
            sc = 1;


            UniversalStarter.testRandomColorImageExtern(resultTxt, tstImage, categories.size(), res,
                    "realImageTst", categories);
        });

        btnStartStop.setOnClickListener(v -> {
            if (isLearning) {
                try {
                    FileManager.setLearningStatus("realImageTst", false);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                btnStartStop.setText(R.string.start_learning);
                isLearning = false;
            } else {
                try {
                    FileManager.setLearningStatus("realImageTst", true);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                learnCustom();
                btnStartStop.setText(R.string.stop_learning);
                isLearning = true;
            }
        });

    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    private void learnCustom() {
        Thread d = new Thread(() -> {
            try {
                UniversalStarter.startLearningWithOtherColorDataSet(percentageText, //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                        res, numHidden,
                        categories.size(),
                        categories, "realImageTst", tstImage, resultTxt);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        d.start();

        //Thread e = new Thread(() -> {
        //    try {
        //        GAStarter starter = new GAStarter();
        //        starter.startLearning(res, numHidden, categories.size(), 3,
        //               "realImageTst", categories, percentageText);
        //     } catch (IOException | ClassNotFoundException f) {
        //        f.printStackTrace();
        //    }
        //});
        //e.start();

        //Thread f = new Thread(() -> {
        //    try {
        //        UniversalTwoHiddenStarter.startLearning(percentageText, res, numHidden, numHiddenTwo, categories.size(), "realImageTst");
        //    } catch (IOException g) {
        //        g.printStackTrace();
        //    }
        //});
       // f.start();
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            onNavigationItemSelected(navigationView.getMenu().getItem(0));
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        //here is the main place where we need to work on.
        int id = item.getItemId();
        switch (id) {

            case R.id.nav_home:
                Intent mStartActivity = new Intent(CustomOtherActivity.this, MainActivity.class);
                int mPendingIntentId = 123456;
                PendingIntent mPendingIntent = PendingIntent.getActivity(CustomOtherActivity.this,
                        mPendingIntentId, mStartActivity, PendingIntent.FLAG_CANCEL_CURRENT);
                AlarmManager mgr = (AlarmManager) CustomOtherActivity.this.getSystemService(Context.ALARM_SERVICE);
                mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 10, mPendingIntent);
                System.exit(0);
                break;

            case R.id.introduction:
                Intent mStartActivityb = new Intent(CustomOtherActivity.this, IntroductionActivity.class);
                int mPendingIntentIdb = 123456;
                PendingIntent mPendingIntentb = PendingIntent.getActivity(CustomOtherActivity.this,
                        mPendingIntentIdb, mStartActivityb, PendingIntent.FLAG_CANCEL_CURRENT);
                AlarmManager mgrb = (AlarmManager) CustomOtherActivity.this.getSystemService(Context.ALARM_SERVICE);
                mgrb.set(AlarmManager.RTC, System.currentTimeMillis() + 10, mPendingIntentb);
                System.exit(0);
                break;

            case R.id.my_net:
                Intent mStartActivityc = new Intent(CustomOtherActivity.this, MyNetActivity.class);
                int mPendingIntentIdc = 123456;
                PendingIntent mPendingIntentc = PendingIntent.getActivity(CustomOtherActivity.this,
                        mPendingIntentIdc, mStartActivityc, PendingIntent.FLAG_CANCEL_CURRENT);
                AlarmManager mgrc = (AlarmManager) CustomOtherActivity.this.getSystemService(Context.ALARM_SERVICE);
                mgrc.set(AlarmManager.RTC, System.currentTimeMillis() + 10, mPendingIntentc);
                System.exit(0);
                break;

            case R.id.calculator:
                Intent mStartActivityd = new Intent(CustomOtherActivity.this, CalculatorActivity.class);
                int mPendingIntentIdd = 123456;
                PendingIntent mPendingIntentd = PendingIntent.getActivity(CustomOtherActivity.this,
                        mPendingIntentIdd, mStartActivityd, PendingIntent.FLAG_CANCEL_CURRENT);
                AlarmManager mgrd = (AlarmManager) CustomOtherActivity.this.getSystemService(Context.ALARM_SERVICE);
                mgrd.set(AlarmManager.RTC, System.currentTimeMillis() + 10, mPendingIntentd);
                System.exit(0);
                break;

            case R.id.nav_more:
                drawer.closeDrawer(GravityCompat.START);
                break;

            case R.id.nav_settings:
                Intent mStartActivitye = new Intent(CustomOtherActivity.this, SettingsActivity.class);
                int mPendingIntentIde = 123456;
                PendingIntent mPendingIntente = PendingIntent.getActivity(CustomOtherActivity.this,
                        mPendingIntentIde, mStartActivitye, PendingIntent.FLAG_CANCEL_CURRENT);
                AlarmManager mgre = (AlarmManager) CustomOtherActivity.this.getSystemService(Context.ALARM_SERVICE);
                mgre.set(AlarmManager.RTC, System.currentTimeMillis() + 10, mPendingIntente);
                System.exit(0);
                break;
        }

        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void requestPermissions() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_DENIED) {
            ActivityCompat
                    .requestPermissions(
                            this,
                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                            0);
        } else if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0);
        }
    }


}