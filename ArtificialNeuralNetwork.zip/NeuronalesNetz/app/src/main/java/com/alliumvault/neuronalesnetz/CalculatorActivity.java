package com.alliumvault.neuronalesnetz;


import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.alliumvault.neuronalesnetz.starters.DefaultStarter;
import com.alliumvault.neuronalesnetz.starters.FileManager;
import com.alliumvault.neuronalesnetz.starters.SymbolStarter;
import com.alliumvault.neuronalesnetz.views.PaintView;
import com.google.android.material.navigation.NavigationView;

public class CalculatorActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout drawer;
    NavigationView navigationView;

    TextView text1, text2;
    PaintView paintView;
    Button btnClear, btnNext, switchMode, btnCalculate;

    Handler handler = new Handler();
    Runnable runnable;

    int delay = 1000;

    boolean numViewEnabled = true;

    StringBuilder expression = new StringBuilder();
    String currChar = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.error, R.string.error);
        //noinspection deprecation
        drawer.setDrawerListener(toggle);
        toggle.syncState();
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        requestPermissions();

        text1 = findViewById(R.id.txt1);
        text2 = findViewById(R.id.txt2);
        btnClear = findViewById(R.id.btn_clear);
        btnNext = findViewById(R.id.btn_stop);
        switchMode = findViewById(R.id.btn_swap);
        btnCalculate = findViewById(R.id.btn_run);

        paintView = (PaintView) findViewById(R.id.paintView);
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        paintView.init(metrics);


        SymbolStarter.load(text1, CalculatorActivity.this);
        DefaultStarter.load(text1, CalculatorActivity.this);

        checkDigit();

        //learnNumbers();
        //learnSymbols();

        switchMode.setOnClickListener(v -> { if (numViewEnabled) {
                switchMode.setText(R.string.num);
                numViewEnabled = false;
            } else {
                switchMode.setText(R.string.sym);
                numViewEnabled = true;
            }
            handler.removeCallbacks(runnable);
            checkDigit();
        });

        btnNext.setOnClickListener(v -> nextNumber());

        btnCalculate.setOnClickListener(v -> calculate());

        btnClear.setOnClickListener(v -> paintView.clear());

        text2.setOnClickListener(v -> {
            expression.setLength(0);
            text2.setText(expression.toString());
        });


    }

    private void nextNumber() {
        paintView.clear();
        expression.append(currChar);
        text2.setText(expression.toString());
        handler.removeCallbacks(runnable);
        checkDigit();
    }

    private void checkDigit() {
        if (numViewEnabled) {
            handler.postDelayed(runnable = () -> {
                handler.postDelayed(runnable, delay);
                currChar = String.valueOf(DefaultStarter.test(FileManager.getDigit(paintView.getBitmap(), 0), CalculatorActivity.this, text1, text1, text1));
            }, delay);

        } else {
            handler.postDelayed(runnable = () -> {
                handler.postDelayed(runnable, delay);
                switch (SymbolStarter.test(FileManager.getDigit(paintView.getBitmap(), 0), CalculatorActivity.this, text1, text1, text1)) {
                    case 0:
                        currChar = "+";
                        break;
                    case 1:
                        currChar = "-";
                        break;
                    case 2:
                        currChar = "*";
                        break;
                    case 3:
                        currChar = "/";
                        break;
                }
            }, delay);
        }
    }

    private void learnNumbers() {
        Thread d = new Thread(() -> {
            //s
            DefaultStarter.startLearning(text1);
        });
        d.start();
    }

    private void learnSymbols() {
        Thread d = new Thread(() -> {
            //s
            SymbolStarter.startLearning(text1);
        });
        d.start();
    }

    private void calculate() {
        String result = String.valueOf(eval(expression.toString()));
        if (result.equals("Infinity") || result.equals("-Infinity")) {
            result = "Ich dachte man kann nicht durch 0 teilen...";
        }
        text2.setText(result);
        expression.setLength(0);
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            onNavigationItemSelected(navigationView.getMenu().getItem(0));
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(runnable);
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        //here is the main place where we need to work on.
        int id = item.getItemId();
        switch (id) {

            case R.id.nav_home:
                Intent mStartActivity = new Intent(CalculatorActivity.this, MainActivity.class);
                int mPendingIntentId = 123456;
                PendingIntent mPendingIntent = PendingIntent.getActivity(CalculatorActivity.this, mPendingIntentId, mStartActivity, PendingIntent.FLAG_CANCEL_CURRENT);
                AlarmManager mgr = (AlarmManager) CalculatorActivity.this.getSystemService(Context.ALARM_SERVICE);
                mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 10, mPendingIntent);
                System.exit(0);
                break;

            case R.id.introduction:
                Intent mStartActivityb = new Intent(CalculatorActivity.this, IntroductionActivity.class);
                int mPendingIntentIdb = 123456;
                PendingIntent mPendingIntentb = PendingIntent.getActivity(CalculatorActivity.this, mPendingIntentIdb, mStartActivityb, PendingIntent.FLAG_CANCEL_CURRENT);
                AlarmManager mgrb = (AlarmManager) CalculatorActivity.this.getSystemService(Context.ALARM_SERVICE);
                mgrb.set(AlarmManager.RTC, System.currentTimeMillis() + 10, mPendingIntentb);
                System.exit(0);
                break;

            case R.id.my_net:
                Intent mStartActivityc = new Intent(CalculatorActivity.this, MyNetActivity.class);
                int mPendingIntentIdc = 123456;
                PendingIntent mPendingIntentc = PendingIntent.getActivity(CalculatorActivity.this, mPendingIntentIdc, mStartActivityc, PendingIntent.FLAG_CANCEL_CURRENT);
                AlarmManager mgrc = (AlarmManager) CalculatorActivity.this.getSystemService(Context.ALARM_SERVICE);
                mgrc.set(AlarmManager.RTC, System.currentTimeMillis() + 10, mPendingIntentc);
                System.exit(0);
                break;

            case R.id.calculator:
                drawer.closeDrawer(GravityCompat.START);
                break;

            case R.id.nav_more:
                Intent mStartActivityd = new Intent(CalculatorActivity.this, MoreActivity.class);
                int mPendingIntentIdd = 123456;
                PendingIntent mPendingIntentd = PendingIntent.getActivity(CalculatorActivity.this, mPendingIntentIdd, mStartActivityd, PendingIntent.FLAG_CANCEL_CURRENT);
                AlarmManager mgrd = (AlarmManager) CalculatorActivity.this.getSystemService(Context.ALARM_SERVICE);
                mgrd.set(AlarmManager.RTC, System.currentTimeMillis() + 10, mPendingIntentd);
                System.exit(0);
                break;

            case R.id.nav_settings:
                Intent mStartActivitye = new Intent(CalculatorActivity.this, SettingsActivity.class);
                int mPendingIntentIde = 123456;
                PendingIntent mPendingIntente = PendingIntent.getActivity(CalculatorActivity.this, mPendingIntentIde, mStartActivitye, PendingIntent.FLAG_CANCEL_CURRENT);
                AlarmManager mgre = (AlarmManager) CalculatorActivity.this.getSystemService(Context.ALARM_SERVICE);
                mgre.set(AlarmManager.RTC, System.currentTimeMillis() + 10, mPendingIntente);
                System.exit(0);
                break;
        }

        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void requestPermissions() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_DENIED) {
            ActivityCompat
                    .requestPermissions(
                            this,
                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                            0);
        } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0);
        }
    }

    public double eval(final String str) {
        return new Object() {
            int pos = -1, ch;

            void nextChar() {
                ch = (++pos < str.length()) ? str.charAt(pos) : -1;
            }

            boolean eat(int charToEat) {
                while (ch == ' ') nextChar();
                if (ch == charToEat) {
                    nextChar();
                    return true;
                }
                return false;
            }

            double parse() {
                nextChar();
                double x = parseExpression();
                if (pos < str.length()) throw new RuntimeException("Unexpected: " + (char) ch);
                return x;
            }

            // Grammar:
            // expression = term | expression `+` term | expression `-` term
            // term = factor | term `*` factor | term `/` factor
            // factor = `+` factor | `-` factor | `(` expression `)`
            //        | number | functionName factor | factor `^` factor

            double parseExpression() {
                double x = parseTerm();
                for (; ; ) {
                    if (eat('+')) x += parseTerm(); // addition
                    else if (eat('-')) x -= parseTerm(); // subtraction
                    else return x;
                }
            }

            double parseTerm() {
                double x = parseFactor();
                for (; ; ) {
                    if (eat('*')) x *= parseFactor(); // multiplication
                    else if (eat('/')) x /= parseFactor(); // division
                    else return x;
                }
            }

            double parseFactor() {
                if (eat('+')) return parseFactor(); // unary plus
                if (eat('-')) return -parseFactor(); // unary minus

                double x;
                int startPos = this.pos;
                if (eat('(')) { // parentheses
                    x = parseExpression();
                    eat(')');
                } else if ((ch >= '0' && ch <= '9') || ch == '.') { // numbers
                    while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();
                    x = Double.parseDouble(str.substring(startPos, this.pos));
                } else if (ch >= 'a' && ch <= 'z') { // functions
                    while (ch >= 'a' && ch <= 'z') nextChar();
                    String func = str.substring(startPos, this.pos);
                    x = parseFactor();
                    if (func.equals("sqrt")) x = Math.sqrt(x);
                    else if (func.equals("sin")) x = Math.sin(Math.toRadians(x));
                    else if (func.equals("cos")) x = Math.cos(Math.toRadians(x));
                    else if (func.equals("tan")) x = Math.tan(Math.toRadians(x));
                    else throw new RuntimeException("Unknown function: " + func);
                } else {
                    throw new RuntimeException("Unexpected: " + (char) ch);
                }

                if (eat('^')) x = Math.pow(x, parseFactor()); // exponentiation

                return x;
            }
        }.parse();
    }

}