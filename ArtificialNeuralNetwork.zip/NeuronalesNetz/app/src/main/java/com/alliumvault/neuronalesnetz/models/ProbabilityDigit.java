package com.alliumvault.neuronalesnetz.models;

public class ProbabilityDigit implements Comparable<ProbabilityDigit> {
    public final int DIGIT;
    public float probability;

    public ProbabilityDigit(int digit, float probability) {
        this.DIGIT = digit;
        this.probability = probability;
    }

    @Override
    public int compareTo(ProbabilityDigit other) {
        return Float.compare(probability, other.probability);
    }
}
