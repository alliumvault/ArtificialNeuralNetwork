package com.alliumvault.neuronalesnetz.starters;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.RequiresApi;

import com.alliumvault.neuronalesnetz.models.Digit;
import com.alliumvault.neuronalesnetz.models.ProbabilityDigit;
import com.alliumvault.neuronalesnetz.strandardnet.InputNeuron;
import com.alliumvault.neuronalesnetz.strandardnet.NeuralNetwork;
import com.alliumvault.neuronalesnetz.strandardnet.WorkingNeuron;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class GAStarter {

    NeuralNetwork nn = new NeuralNetwork();
    List<Digit> digits;
    List<Digit> testDigits;
    InputNeuron[][] inputs;
    WorkingNeuron[] outputs;

    double bestPercentage = 0.0;
    float[] bestWeights;

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void startLearning(int res, int numHiddenNeurons, int numOutputs, int numRandomNetworks,
                              String networkTitle,
                              ArrayList<String> categories,
                              TextView uni) throws IOException, ClassNotFoundException {

        inputs = new InputNeuron[res][res*3];
        outputs = new WorkingNeuron[numOutputs];

        for (int i = 0; i < res; i++) {
            for (int k = 0; k < res*3; k++) {
                inputs[i][k] = nn.createNewInput();
            }
        }

        for (int i = 0; i < numOutputs; i++) {
            outputs[i] = nn.createNewOutput();
        }

        nn.createHiddenNeurons(numHiddenNeurons);

        int weightsSize = (res * (res*3)) * numHiddenNeurons + numHiddenNeurons * numOutputs;

        bestWeights = FileManager.getCustomWeights(networkTitle);


        nn.createFullMesh(bestWeights);
        double firstPercentage = getPercentage(nn, networkTitle, categories, res, numOutputs);
        Log.d("lllll", "percentage: " + firstPercentage + "%");
        if (firstPercentage >= bestPercentage) {
            bestPercentage = firstPercentage;
        }


        for (int i = 0; i < numRandomNetworks; i++) {
            Random rand = new Random();
            float[] currentWeights = new float[weightsSize];
            for (int j = 0; j < currentWeights.length; j++) {
                currentWeights[j] = rand.nextFloat();
            }
            nn.resetAllWeights();
            nn.createFullMesh(currentWeights);

            double currentPercentage = getPercentage(nn, networkTitle, categories, res, numOutputs);

            Log.d("lllll", "percentage: " + currentPercentage + "%");

            if (currentPercentage >= bestPercentage) {
                bestPercentage = currentPercentage;
                bestWeights = currentWeights;
            }
        }

        while (FileManager.getLearningStatus(networkTitle)) {
            float[] currentWeights;
            currentWeights = mutate(bestWeights);
            nn.resetAllWeights();
            nn.createFullMesh(currentWeights);

            double currentPercentage = getPercentage(nn, networkTitle, categories, res, numOutputs);

            Log.d("lllll","percentage: " + currentPercentage + "%");

            if (currentPercentage > bestPercentage) {
                bestPercentage = currentPercentage;
                bestWeights = currentWeights;
                Handler handler = new Handler(Looper.getMainLooper());
                handler.post(() -> uni.setText(String.valueOf(bestPercentage)));
            }
        }

    }

    private float[] mutate(float... weights) {
        float[] mutatedWeights;
        Random rand = new Random();
        int mutationRate = 3;

        mutatedWeights = weights.clone();

        for (int i = 0; i < weights.length; i++) {

            float currentMutation = (float) 0.0;

            if (i % mutationRate == 0) {
                currentMutation = rand.nextFloat();
                mutatedWeights[i] = weights[i] * (currentMutation + (float) 0.3);
            }

            if (i % 10000 == 0) {
                Log.d("lll", mutatedWeights[i] + "  |  " + weights[i] + "  |  " + (currentMutation + (float) 0.2));
            }
        }

        return mutatedWeights;
    }

    private double getPercentage(NeuralNetwork nn, String netName, ArrayList<String> categories, int res, int numOut) {
        int correct = 0;
        int incorrect = 0;
        int c = 0;
        while (c < 20) {


            for (int i = 0; i < categories.size(); i++) {
                nn.resetHiddenTwo();
                Digit currentDigit = FileManager.getDigitOfCategory(categories.get(i), netName, res);
                for (int x = 0; x < res; x++) {
                    for (int y = 0; y < res; y++) {
                        inputs[x][y].setValue(currentDigit.data[x][y]);
                    }
                }


                ProbabilityDigit[] probabilityDigits = new ProbabilityDigit[numOut];
                for (int k = 0; k < probabilityDigits.length; k++) {
                    probabilityDigits[k] = new ProbabilityDigit(k, outputs[k].getValue());
                    Log.d("llll", "Connections" + k + ": " + outputs[k].getValue());
                }

                Arrays.sort(probabilityDigits, Collections.reverseOrder());

                if (i == probabilityDigits[0].DIGIT) {
                    Log.d("llll", "was correct");
                    correct++;
                } else {
                    Log.d("llll", "was not correct");
                    incorrect++;
                }
                c++;
            }
        }

        return ((double) correct / (double) (correct + incorrect)) * 100;
    }

}

