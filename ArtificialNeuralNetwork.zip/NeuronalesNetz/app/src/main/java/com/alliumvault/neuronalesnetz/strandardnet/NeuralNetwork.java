package com.alliumvault.neuronalesnetz.strandardnet;


import android.util.Log;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class NeuralNetwork implements Serializable {
    private final List<InputNeuron> inputNeurons = new ArrayList<>();
    private final List<WorkingNeuron> hiddenNeurons = new ArrayList<>();
    private final List<WorkingNeuron> hiddenNeuronsTwo = new ArrayList<>();
    private final List<WorkingNeuron> outputNeurons = new ArrayList<>();
    private int trainingSample = 0;


    public WorkingNeuron createNewOutput() {
        WorkingNeuron wn = new WorkingNeuron();
        outputNeurons.add(wn);
        return wn;
    }

    public InputNeuron createNewInput() {
        InputNeuron in = new InputNeuron();
        inputNeurons.add(in);
        return in;
    }

    public void reset() {
        for (WorkingNeuron wn : outputNeurons) {
            wn.reset();
        }
        for (WorkingNeuron wn : hiddenNeurons) {
            wn.reset();
        }
    }

    public void resetHiddenTwo() {
        for (WorkingNeuron wn : outputNeurons) {
            wn.reset();
        }
        for (WorkingNeuron wn : hiddenNeurons) {
            wn.reset();
        }
        for (WorkingNeuron wn : hiddenNeuronsTwo) {
            wn.reset();
        }
    }

    public void createFullMesh() {
        if (hiddenNeurons.size() == 0) {
            int index = 0;

            for (WorkingNeuron wn : outputNeurons) {
                for (InputNeuron in : inputNeurons) {
                    wn.addConnection(new Connection(in, 0));
                }
            }

        } else {
            for (WorkingNeuron wn : outputNeurons) {
                for (WorkingNeuron hidden : hiddenNeurons) {
                    wn.addConnection(new Connection(hidden, 0));
                }
            }

            for (WorkingNeuron hidden : hiddenNeurons) {
                for (InputNeuron in : inputNeurons) {
                    hidden.addConnection(new Connection(in, 0));
                }
            }
        }
    }

    public void createHiddenNeurons(int amount) {
        for (int i = 0; i < amount; i++) {
            hiddenNeurons.add(new WorkingNeuron());
        }
    }

    public void createHiddenNeuronsTwo(int amount) {
        for (int i = 0; i < amount; i++) {
            hiddenNeuronsTwo.add(new WorkingNeuron());
        }
    }

    public void backpropagation(float[] shoulds, float epsilon) {
        if (shoulds.length != outputNeurons.size()) {
            throw new IllegalArgumentException();
        }

//        Log.e("GGGGGGG", shoulds.length + "|" + epsilon);

        ////////////////////////////////////////////////////////////////////////////////////reset();
        resetHiddenTwo();

        for (int i = 0; i < shoulds.length; i++) {
            outputNeurons.get(i).calculateOutputDelta(shoulds[i]);
        }

        if (hiddenNeurons.size() > 0) {
            for (int i = 0; i < shoulds.length; i++) {
                outputNeurons.get(i).backpropagateSmallDelta();
            }
        }

        if (hiddenNeuronsTwo.size() > 0) {
            for (int i = 0; i < hiddenNeuronsTwo.size(); i++) {
                hiddenNeuronsTwo.get(i).backpropagateSmallDelta();
            }
        }

        for (int i = 0; i < shoulds.length; i++) {
            outputNeurons.get(i).deltaLearning(epsilon);
        }

        for (int i = 0; i < hiddenNeuronsTwo.size(); i++) {
            hiddenNeuronsTwo.get(i).deltaLearning(epsilon);
        }

        for (int i = 0; i < hiddenNeurons.size(); i++) {
            hiddenNeurons.get(i).deltaLearning(epsilon);
        }

        if (trainingSample % 2 == 0) {
            for (int i = 0; i < shoulds.length; i++) {
                outputNeurons.get(i).applyBatch();
            }

            for (int i = 0; i < hiddenNeuronsTwo.size(); i++) {
                hiddenNeuronsTwo.get(i).applyBatch();
            }

            for (int i = 0; i < hiddenNeurons.size(); i++) {
                hiddenNeurons.get(i).applyBatch();
            }
        }

        trainingSample++;
    }


    public void createFullMesh(float... weights) {
        if (hiddenNeurons.size() == 0) {
            if (weights.length != inputNeurons.size() * outputNeurons.size()) {
                throw new RuntimeException();
            }

            int index = 0;

            for (WorkingNeuron wn : outputNeurons) {
                for (InputNeuron in : inputNeurons) {
                    wn.addConnection(new Connection(in, weights[index++]));

                }
            }

        } else if (hiddenNeuronsTwo.size() == 0) {

            if (weights.length != inputNeurons.size() * hiddenNeurons.size() + hiddenNeurons.size() * outputNeurons.size()) {
                Log.d("GGGGGGGGGG", weights.length + "III" + inputNeurons.size() * hiddenNeurons.size() + hiddenNeurons.size() * outputNeurons.size());
                throw new RuntimeException();
            }

            int index = 0;

            for (WorkingNeuron hidden : hiddenNeurons) {
                for (InputNeuron in : inputNeurons) {
                    hidden.addConnection(new Connection(in, weights[index++]));
                }
            }

            for (WorkingNeuron out : outputNeurons) {
                for (WorkingNeuron hidden : hiddenNeurons) {
                    out.addConnection(new Connection(hidden, weights[index++]));
                }
            }
        } else {

            //////////////////////////////////////////////////////////////////////////////////////////////////////


            if (weights.length != inputNeurons.size() * hiddenNeurons.size() + hiddenNeurons.size() * hiddenNeuronsTwo.size() +
                    hiddenNeuronsTwo.size() * outputNeurons.size()) {
                Log.d("GGGGGGGGGG", weights.length + "III" + (inputNeurons.size() * hiddenNeurons.size() +
                        hiddenNeurons.size() * hiddenNeuronsTwo.size() +
                        hiddenNeuronsTwo.size() * outputNeurons.size()));
                Log.d("GGGGGGGGGG", inputNeurons.size() + " (inputs)");
                throw new RuntimeException();
            }

            int index = 0;

            for (WorkingNeuron hidden : hiddenNeurons) {
                for (InputNeuron in : inputNeurons) {
                    hidden.addConnection(new Connection(in, weights[index++]));
                }
            }

            for (WorkingNeuron hidden2 : hiddenNeuronsTwo) {
                for (WorkingNeuron hidden1 : hiddenNeurons) {
                    hidden2.addConnection(new Connection(hidden1, weights[index++]));
                }
            }

            for (WorkingNeuron out : outputNeurons) {
                for (WorkingNeuron hidden2 : hiddenNeuronsTwo) {
                    out.addConnection(new Connection(hidden2, weights[index++]));
                }
            }


            //////////////////////////////////////////////////////////////////////////////////////////////////////


        }
    }

    public void resetAllWeights() {
        for (WorkingNeuron wn : hiddenNeurons) {
            wn.deleteAllConnections();
        }

        for (WorkingNeuron wn : hiddenNeuronsTwo) {
            wn.deleteAllConnections();
        }

        for (WorkingNeuron wn : outputNeurons) {
            wn.deleteAllConnections();
        }
    }

    public float[] getWeights(int numHidden, int numOut, int res) {
        float[] weights = new float[res * res * numHidden + numHidden * numOut];

        int indexWeights = 0;

        for (WorkingNeuron hidden : hiddenNeurons) {
            List<Connection> connectionsHidden = hidden.getConnections();

            for (int i = 0; i < connectionsHidden.size(); i++) {
                weights[indexWeights] = connectionsHidden.get(i).getWeight();
                indexWeights++;
            }

        }

        for (WorkingNeuron out : outputNeurons) {
            List<Connection> connectionsHidden = out.getConnections();

            for (int i = 0; i < connectionsHidden.size(); i++) {
                weights[indexWeights] = connectionsHidden.get(i).getWeight();
                indexWeights++;
            }

        }
        return weights;
    }

    public float[] getColorWeights(int numHidden, int numOut, int res) {
        float[] weights = new float[res * (res * 3) * numHidden + numHidden * numOut];

        int indexWeights = 0;

        for (WorkingNeuron hidden : hiddenNeurons) {
            List<Connection> connectionsHidden = hidden.getConnections();

            for (int i = 0; i < connectionsHidden.size(); i++) {
                weights[indexWeights] = connectionsHidden.get(i).getWeight();
                indexWeights++;
            }

        }

        for (WorkingNeuron out : outputNeurons) {
            List<Connection> connectionsHidden = out.getConnections();

            for (int i = 0; i < connectionsHidden.size(); i++) {
                weights[indexWeights] = connectionsHidden.get(i).getWeight();
                indexWeights++;
            }

        }
        return weights;
    }

    public float[] getHiddenTwoWeights(int numHidden, int numOut, int res, int numHiddenTwo) {
        float[] weights = new float[res * res * numHidden + numHidden * numHiddenTwo + numHiddenTwo * numOut];

        int indexWeights = 0;

        for (WorkingNeuron hidden : hiddenNeurons) {
            List<Connection> connectionsHidden = hidden.getConnections();

            for (int i = 0; i < connectionsHidden.size(); i++) {
                weights[indexWeights] = connectionsHidden.get(i).getWeight();
                indexWeights++;
            }

        }

        for (WorkingNeuron hidden : hiddenNeuronsTwo) {
            List<Connection> connectionsHidden = hidden.getConnections();

            for (int i = 0; i < connectionsHidden.size(); i++) {
                weights[indexWeights] = connectionsHidden.get(i).getWeight();
                indexWeights++;
            }

        }

        for (WorkingNeuron out : outputNeurons) {
            List<Connection> connectionsHidden = out.getConnections();

            for (int i = 0; i < connectionsHidden.size(); i++) {
                weights[indexWeights] = connectionsHidden.get(i).getWeight();
                indexWeights++;
            }

        }
        return weights;
    }

    public float[] getColorHiddenTwoWeights(int numHidden, int numOut, int res, int numHiddenTwo) {
        float[] weights = new float[res * (res * 3) * numHidden + numHidden * numHiddenTwo + numHiddenTwo * numOut];

        int indexWeights = 0;

        for (WorkingNeuron hidden : hiddenNeurons) {
            List<Connection> connectionsHidden = hidden.getConnections();

            for (int i = 0; i < connectionsHidden.size(); i++) {
                weights[indexWeights] = connectionsHidden.get(i).getWeight();
                indexWeights++;
            }

        }

        for (WorkingNeuron hidden : hiddenNeuronsTwo) {
            List<Connection> connectionsHidden = hidden.getConnections();

            for (int i = 0; i < connectionsHidden.size(); i++) {
                weights[indexWeights] = connectionsHidden.get(i).getWeight();
                indexWeights++;
            }

        }

        for (WorkingNeuron out : outputNeurons) {
            List<Connection> connectionsHidden = out.getConnections();

            for (int i = 0; i < connectionsHidden.size(); i++) {
                weights[indexWeights] = connectionsHidden.get(i).getWeight();
                indexWeights++;
            }

        }
        return weights;
    }

}
