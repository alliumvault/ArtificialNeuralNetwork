package com.alliumvault.neuronalesnetz.databases;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.alliumvault.neuronalesnetz.models.NetListModel;

import java.util.ArrayList;
import java.util.List;


public class NetListDatabaseHandler extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_LISTS = "liststable";
    private static final String TABLE_NAME = "lists";
    private static final String KEY_ID = "id";
    private static final String KEY_TITLE = "name";
    private static final String KEY_ID_NAME = "idName";

    public NetListDatabaseHandler(Context context) {
        super(context, TABLE_NAME, null, DATABASE_VERSION);
        //3rd argument to be passed is CursorFactory instance
        //2nd argument to be passed is the table name
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TRACKING_TABLE = "CREATE TABLE " + TABLE_LISTS + "("
                + KEY_ID + " INTEGER PRIMARY KEY," + KEY_TITLE + " TEXT,"
                + KEY_ID_NAME + " TEXT" + ")";
        db.execSQL(CREATE_TRACKING_TABLE);


    }

    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LISTS);

        // Create tables again
        onCreate(db);
    }

    // code to add the new location
    public void addList(String title, String idName) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_TITLE, title);
        values.put(KEY_ID_NAME, idName);

        // Inserting Row
        db.insert(TABLE_LISTS, null, values);
        //2nd argument is String containing nullColumnHack
        db.close(); // Closing database connection
    }


    // code to get all locations in a list view
    public List<NetListModel> getAllLists() {
        List<NetListModel> listList = new ArrayList<>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_LISTS;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                NetListModel currList = new NetListModel();
                currList.setTitle(cursor.getString(1));
                currList.setIdName(cursor.getString(2));
                // Adding contact to list
                listList.add(currList);
            } while (cursor.moveToNext());
        }

        // return location list
        return listList;
    }

    public void delete(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        //db.delete(TABLE_LISTS, KEY_TITLE + "=" + name, null);
        db.delete(TABLE_LISTS, KEY_TITLE + "=?", new String[]{name});
    }


    // Getting locations Count
    public int getListsCount() {
        String locationQuery = "SELECT  * FROM " + TABLE_LISTS;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(locationQuery, null);
        cursor.close();

        // return count
        return cursor.getCount();
    }

}
