package com.alliumvault.neuronalesnetz.strandardnet;

public abstract class Neuron {
    public abstract float getValue();
}
