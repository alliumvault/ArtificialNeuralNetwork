package com.alliumvault.neuronalesnetz;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class MoreActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout drawer;
    NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.error, R.string.error);
        //noinspection deprecation
        drawer.setDrawerListener(toggle);
        toggle.syncState();
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            onNavigationItemSelected(navigationView.getMenu().getItem(0));
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        //here is the main place where we need to work on.
        int id = item.getItemId();
        switch (id) {

            case R.id.nav_home:
                Intent aIntent = new Intent(this, MainActivity.class);
                startActivity(aIntent);
                break;

            case R.id.introduction:
                Intent bIntent = new Intent(this, IntroductionActivity.class);
                startActivity(bIntent);
                break;

            case R.id.my_net:
                Intent dIntent = new Intent(this, MyNetActivity.class);
                startActivity(dIntent);
                break;

            case R.id.calculator:
                Intent cIntent = new Intent(this, CalculatorActivity.class);
                startActivity(cIntent);
                break;

            case R.id.nav_more:
                drawer.closeDrawer(GravityCompat.START);
                break;

            case R.id.nav_settings:
                Intent eIntent = new Intent(this, SettingsActivity.class);
                startActivity(eIntent);
                break;
        }

        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

}