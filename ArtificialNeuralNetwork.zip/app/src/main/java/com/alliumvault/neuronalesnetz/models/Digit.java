package com.alliumvault.neuronalesnetz.models;

public class Digit {
    public int label;
    public float[][] data;

    public Digit(int label, float[][] data) {
        this.label = label;
        this.data = data;
    }
}
