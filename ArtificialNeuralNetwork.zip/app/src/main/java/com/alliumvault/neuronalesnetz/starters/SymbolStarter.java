package com.alliumvault.neuronalesnetz.starters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.TextView;

import com.alliumvault.neuronalesnetz.models.Digit;
import com.alliumvault.neuronalesnetz.models.ProbabilityDigit;
import com.alliumvault.neuronalesnetz.strandardnet.InputNeuron;
import com.alliumvault.neuronalesnetz.strandardnet.NeuralNetwork;
import com.alliumvault.neuronalesnetz.strandardnet.WorkingNeuron;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class SymbolStarter {
    public static NeuralNetwork nn = new NeuralNetwork();
    public static List<Digit> digits;
    public static List<Digit> testDigits;
    public static InputNeuron[][] inputs = new InputNeuron[28][28];
    public static WorkingNeuron[] outputs = new WorkingNeuron[4];

    public static void start(TextView uni, boolean shouldLearn, Context context) throws IOException, ClassNotFoundException {
        if (shouldLearn) {
            startLearning(uni);
        } else {
            load(uni, context);
        }
    }

    public static void startLearning(TextView uni) {

        digits = FileManager.loadDataSet();
        testDigits = FileManager.getTestData();

        for (int i = 0; i < 28; i++) {
            for (int k = 0; k < 28; k++) {
                inputs[i][k] = nn.createNewInput();
            }
        }

        for (int i = 0; i < 4; i++) {
            outputs[i] = nn.createNewOutput();
        }

        int numHiddenNeurons = 100;

        nn.createHiddenNeurons(numHiddenNeurons);

        Random rand = new Random();
        float[] weights = new float[28 * 28 * numHiddenNeurons + numHiddenNeurons * 4];
        for (int i = 0; i < weights.length; i++) {
            weights[i] = rand.nextFloat();
        }

        nn.createFullMesh(weights);

        Handler mHandler = new Handler(Looper.getMainLooper());
        mHandler.post(() -> uni.setText("10%"));


        float epsilon = 0.0005f;
        int s = 0;
        int times = 50;
        while (s < times) {

            for (int i = 0; i < digits.size(); i++) {
                for (int x = 0; x < 28; x++) {
                    for (int y = 0; y < 28; y++) {
                        inputs[x][y].setValue(digits.get(i).data[x][y]);
                    }
                }

                float[] shoulds = new float[4];
                shoulds[digits.get(i).label] = 1;
                nn.backpropagation(shoulds, epsilon);
            }
            s++;
            epsilon *= 0.99;
            testProgress(uni);
            try {
                saveNet(nn, numHiddenNeurons);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(() -> uni.append(" (done)"));
    }

    private static void saveNet(NeuralNetwork net, int numHidden) throws IOException {
        FileManager.saveSymbolWeights(net, numHidden);
    }

    private static void testProgress(TextView uni) {
        int correct = 0;
        int incorrect = 0;
        for (int i = 0; i < testDigits.size(); i++) {
            nn.reset();
            for (int x = 0; x < 28; x++) {
                for (int y = 0; y < 28; y++) {
                    inputs[x][y].setValue(testDigits.get(i).data[x][y]);
                }
            }

            ProbabilityDigit[] probabilityDigits = new ProbabilityDigit[4];
            for (int k = 0; k < probabilityDigits.length; k++) {
                probabilityDigits[k] = new ProbabilityDigit(k, outputs[k].getValue());
            }

            Arrays.sort(probabilityDigits, Collections.reverseOrder());

            if (testDigits.get(i).label == probabilityDigits[0].DIGIT) {
                correct++;
            } else {
                incorrect++;
            }
        }

        float percentage = (float) correct / (float) (correct + incorrect);
        Log.d("sss", "percentage: " + percentage * 100);

        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(() -> uni.setText(percentage * 100 + "%"));
    }


    public static void load(TextView uni, Context context) {
        for (int i = 0; i < 28; i++) {
            for (int k = 0; k < 28; k++) {
                inputs[i][k] = nn.createNewInput();
            }
        }

        for (int i = 0; i < 4; i++) {
            outputs[i] = nn.createNewOutput();
        }

        int numHiddenNeurons = 100;

        nn.createHiddenNeurons(numHiddenNeurons);


        float[] weights = new float[28 * 28 * numHiddenNeurons + numHiddenNeurons * 4];

        try {
            float[] readWeights = FileManager.getSymbolWeights(context);
            if (readWeights.length == weights.length) {
                nn.createFullMesh(readWeights);
                Handler handler = new Handler(Looper.getMainLooper());
                handler.post(() -> uni.setText("loaded weights"));
            } else {
                throw new IllegalArgumentException();
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }


    }

    @SuppressLint("SetTextI18n")
    public static int test(Digit d, Context mContext, TextView result1Text, TextView result2Text, TextView result3Text) {
        nn.reset();
        for (int x = 0; x < 28; x++) {
            for (int y = 0; y < 28; y++) {
                inputs[x][y].setValue(d.data[x][y]);
            }
        }

        ProbabilityDigit[] probs = new ProbabilityDigit[4];
        for (int k = 0; k < probs.length; k++) {
            probs[k] = new ProbabilityDigit(k, outputs[k].getValue());
            //Log.d("sss", "Connections" + k + ": " + outputs[k].getValue());
        }

        Arrays.sort(probs, Collections.reverseOrder());


        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(() -> {
            //if (probs[0].probability > 0.5) {
            //    result1Text.setText(probs[0].DIGIT + "  (" + probs[0].probability * 100 + "%)");
            //} else {
            //    result1Text.setText(probs[0].DIGIT + "  (" + probs[0].probability * 100 + "%)  --> UNSICHER");
            //}
            //result2Text.setText(probs[1].DIGIT + "  (" + probs[1].probability * 100 + "%)");
            //result3Text.setText(probs[2].DIGIT + "  (" + probs[2].probability + 100 + "%)");

            String out = "";
            switch (probs[0].DIGIT) {
                case 0:
                    out = "+" + "  (" + probs[0].probability * 100 + "%)";
                    break;
                case 1:
                    out = "-" + "  (" + probs[0].probability * 100 + "%)";
                    break;
                case 2:
                    out = "*" + "  (" + probs[0].probability * 100 + "%)";
                    break;
                case 3:
                    out = "/" + "  (" + probs[0].probability * 100 + "%)";
                    break;
            }
            result1Text.setText(out);

        });

        return probs[0].DIGIT;
    }

}
