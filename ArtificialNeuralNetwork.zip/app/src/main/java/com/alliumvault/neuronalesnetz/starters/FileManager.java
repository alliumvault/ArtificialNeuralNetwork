package com.alliumvault.neuronalesnetz.starters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;

import com.alliumvault.neuronalesnetz.models.Digit;
import com.alliumvault.neuronalesnetz.strandardnet.NeuralNetwork;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class FileManager {
    private static final List<Digit> digits = new ArrayList<>();

    public static List<Digit> loadDataSet() {
        File sdCard = Environment.getExternalStorageDirectory();
        File dir = new File(sdCard.getAbsolutePath() + "/ImagesKNN");
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inPreferredConfig = Bitmap.Config.ARGB_8888;
                Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());

                float[][] pixels = new float[28][28];
                for (int i = 0; i < 28; i++) {
                    for (int k = 0; k < 28; k++) {

                        int pixel = bitmap.getPixel(i, k);

                        // extract each color component
                        int red = (pixel >>> 16) & 0xFF;
                        int green = (pixel >>> 8) & 0xFF;
                        int blue = (pixel) & 0xFF;

                        // calc luminance in range 0.0 to 1.0; using SRGB luminance constants
                        float luminance = (red * 0.2126f + green * 0.7152f + blue * 0.0722f) / 255;

                        if (luminance == 1.0) {
                            pixels[i][k] = (float) 0.0;
                        } else {
                            pixels[i][k] = (float) 0.9;
                        }

                        pixels[i][k] = (float) 1.0 - luminance;
                    }
                }

                String test = file.getName();
                String number = test.substring(test.lastIndexOf("_") + 1);
                char firstChar = number.charAt(0);
                digits.add(new Digit(Integer.parseInt(String.valueOf(firstChar)), pixels));
            }
        }
        return digits;
    }

    public static List<Digit> getTestData() {
        File sdCard = Environment.getExternalStorageDirectory();
        File dir = new File(sdCard.getAbsolutePath() + "/ImagesKNNW/test");
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inPreferredConfig = Bitmap.Config.ARGB_8888;
                Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());

                float[][] pixels = new float[28][28];
                for (int i = 0; i < 28; i++) {
                    for (int k = 0; k < 28; k++) {

                        int pixel = bitmap.getPixel(i, k);

                        // extract each color component
                        int red = (pixel >>> 16) & 0xFF;
                        int green = (pixel >>> 8) & 0xFF;
                        int blue = (pixel) & 0xFF;

                        // calc luminance in range 0.0 to 1.0; using SRGB luminance constants
                        float luminance = (red * 0.2126f + green * 0.7152f + blue * 0.0722f) / 255;

                        if (luminance == 1.0) {
                            pixels[i][k] = (float) 0.0;
                        } else {
                            // pixels[i][k] = luminance;
                            pixels[i][k] = (float) 0.9;
                        }

                        pixels[i][k] = (float) 1.0 - luminance;

                    }
                }

                String test = file.getName();
                String number = test.substring(test.lastIndexOf("_") + 1);
                char firstChar = number.charAt(0);
                digits.add(new Digit(Integer.parseInt(String.valueOf(firstChar)), pixels));
            }
        }
        return digits;
    }


    public static void addDigit(Bitmap bitmap, int label) {
        Bitmap bitmapScaled = Bitmap.createScaledBitmap(bitmap, 28, 28, false);

        File sdCard = Environment.getExternalStorageDirectory();
        File dir = new File(sdCard.getAbsolutePath() + "/ImagesKNN");
        dir.mkdirs();
        File file = new File(dir, System.currentTimeMillis() + "_" + label + ".png");


        try (FileOutputStream out = new FileOutputStream(file)) {
            bitmapScaled.compress(Bitmap.CompressFormat.PNG, 100, out);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Digit getDigit(Bitmap b, int label) {
        Bitmap bitmapScaled = Bitmap.createScaledBitmap(b, 28, 28, false);
        float[][] pixels = new float[28][28];
        for (int i = 0; i < 28; i++) {
            for (int k = 0; k < 28; k++) {

                int pixel = bitmapScaled.getPixel(i, k);

                int red = (pixel >>> 16) & 0xFF;
                int green = (pixel >>> 8) & 0xFF;
                int blue = (pixel) & 0xFF;

                float luminance = (red * 0.2126f + green * 0.7152f + blue * 0.0722f) / 255;
                if (luminance == 1.0) {
                    pixels[i][k] = (float) 0.0;
                } else {
                    pixels[i][k] = pixels[i][k] = (float) 0.9;
                }

                pixels[i][k] = (float) 1.0 - luminance;
            }
        }

        return new Digit(label, pixels);
    }

    public static float[] getSymbolWeights(Context context) throws IOException, ClassNotFoundException {
        InputStream fis = context.getAssets().open("symbols.weights");

        ObjectInputStream in = new ObjectInputStream(fis);
        float[] weights = (float[]) in.readObject();
        in.close();

        return weights;
    }

    public static float[] getNumWeights(Context context) throws IOException, ClassNotFoundException {
        InputStream fis = context.getAssets().open("num.weights");

        ObjectInputStream in = new ObjectInputStream(fis);
        float[] weights = (float[]) in.readObject();
        in.close();

        return weights;
    }


    public static void saveNumWeights(NeuralNetwork net, int numHidden) throws IOException {
        File sdCard = Environment.getExternalStorageDirectory();
        File dir = new File(sdCard.getAbsolutePath() + "/ImagesKNNW");
        dir.mkdirs();
        File file = new File(dir, "weights");
        file.mkdirs();
        File weightsFile = new File(file, "num" + ".weights");

        ObjectOutputStream out = new ObjectOutputStream(
                new FileOutputStream(weightsFile)
        );
        out.writeObject(net.getWeights(numHidden, 10));
        out.flush();
        out.close();
    }

    public static void saveSymbolWeights(NeuralNetwork net, int numHidden) throws IOException {
        File sdCard = Environment.getExternalStorageDirectory();
        File dir = new File(sdCard.getAbsolutePath() + "/ImagesKNNW");
        dir.mkdirs();
        File file = new File(dir, "weights");
        file.mkdirs();
        File weightsFile = new File(file, "symbol" + ".weights");

        ObjectOutputStream out = new ObjectOutputStream(
                new FileOutputStream(weightsFile)
        );
        out.writeObject(net.getWeights(numHidden, 4));
        out.flush();
        out.close();
    }
}
